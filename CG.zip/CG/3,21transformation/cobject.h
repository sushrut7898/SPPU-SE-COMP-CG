#ifndef COBJECT_H
#define COBJECT_H
#include"transform.h"

class cobject
{
public:
    int xy[10][3],n;
    void setxy(int xy1[][2],int n1)
    {
        n=n1;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<2;j++)
            {
                xy[i][j]=xy1[i][j];
            }
            xy[i][2]=1;
        }
    }
    cobject operator *(Transform a)
    {
        cobject res;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<3;j++)
            {
                res.xy[i][j]=0;
                for(int k=0;k<3;k++)
                {
                    res.xy[i][j]=(float)res.xy[i][j]+(float)((float)xy[i][k]*(float)a.mat[k][j]);
                }
            }
        }
        return res;
    }

};
#endif // COBJECT_H
