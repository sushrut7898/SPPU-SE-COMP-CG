#ifndef TRANSFORM_H
#define TRANSFORM_H
#include<math.h>


class Transform
{
public:
    float mat[3][3];
    int tx,ty;
    float shx,shy;
    float sx,sy,angle,sine,cosine;
    Transform()
    {
        init();
    }
    void init()
    {
        for(int i=0;i<3;i++)
        {
            for(int j=0;j<3;j++)
            {
                if(i==j)
                {
                    mat[i][j]=1;
                }
                else
                {
                    mat[i][j]=0;
                }
            }
        }
    }

    void translate(int x,int y)
    {
        init();
        tx=x;
        ty=y;
        mat[2][0]=tx;
        mat[2][1]=ty;
    }
    void rotate(int theta)
    {
        init();
        angle=theta*3.14/180;
        cosine=cos(angle);
        sine=sin(angle);
        mat[0][0]=cosine;
        mat[0][1]=sine;
        mat[1][0]=-sine;
        mat[1][1]=cosine;
    }
    void scale(float x,float y)
    {
        init();
        sx=x;
        sy=y;
        mat[0][0]=sx;
        mat[1][1]=sy;
    }

    void shear(float x,float y)
    {
        init();

        shx=x;
        shy=y;
        mat[1][0]=shx;
        mat[0][1]=shy;
    }

};

#endif // TRANSFORM_H
