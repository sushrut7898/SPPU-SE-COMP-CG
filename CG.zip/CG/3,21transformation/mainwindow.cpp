#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QInputDialog>
#include<cstring>
#include"cobject.h"
#include<QPainter>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    inputObject();
    flag=0;
}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::paintEvent(QPaintEvent *)
{

    QPainter painter(this);
    QPen pen(Qt::black,2,Qt::SolidLine,Qt::RoundCap);
    painter.setPen(pen);

    painter.drawLine(0,this->height()/2,this->width(),this->height()/2);
    painter.drawLine(this->width()/2,0,this->width()/2,this->height());

    xmid=this->width()/2;
    ymid=this->height()/2;
    if(flag==0)
    {
       // inputObject();
        displayObject();
    }
    if(flag==1)
    {
        int tx,ty;
        tx=ui->tx->toPlainText().toInt();
        ty=ui->ty->toPlainText().toInt();
        tm.translate(tx,ty);
        o1=o1*tm;
        displayObject();

    }
    if(flag==2)
    {
        float sx,sy;
        sx=ui->sx->toPlainText().toFloat();
        sy=ui->sy->toPlainText().toFloat();
        tm.scale(sx,sy);
        o1=o1*tm;
        displayObject();

    }
    if(flag==3)
    {
        int angle;
        angle=ui->angle->toPlainText().toInt();
        tm.rotate(angle);
        o1=o1*tm;
        displayObject();

    }
    if(flag==4)
    {
        float shx,shy;
        shx=ui->shx->toPlainText().toFloat();
        shy=ui->shy->toPlainText().toFloat();
        tm.shear(shx,shy);
        o1=o1*tm;
        displayObject();

    }
    flag=0;

}



void MainWindow::inputObject()
{
    int temp[10][2];
    n=QInputDialog::getInt(this,"Object","Enter total number of vertices : ");
    for(int i=0;i<n;i++)
    {
        temp[i][0]=QInputDialog::getInt(this,"X","Enter X Co-ordinate : ");
        temp[i][1]=QInputDialog::getInt(this,"Y","Enter Y Co-ordinate : ");
    }
    o1.setxy(temp,n);
    return;
}

void MainWindow::displayObject()
{
    QPainter painter(this);
    QPen pen(Qt::red,2,Qt::SolidLine,Qt::RoundCap);
    painter.setPen(pen);
    int i;
    for(i=0;i<n-1;i++)
    {
        painter.drawLine(xmid+o1.xy[i][0],ymid-o1.xy[i][1],xmid+o1.xy[i+1][0],ymid-o1.xy[i+1][1]);
    }
    painter.drawLine(xmid+o1.xy[i][0],ymid-o1.xy[i][1],xmid+o1.xy[0][0],ymid-o1.xy[0][1]);

}

void MainWindow::on_ttranslate_clicked()
{
    flag=1;
    update();

}

void MainWindow::on_scale_clicked()
{
    flag=2;
    update();

}

void MainWindow::on_rotate_clicked()
{
    flag=3;
    update();
}

void MainWindow::on_shear_clicked()
{
    flag=4;
    update();
}
