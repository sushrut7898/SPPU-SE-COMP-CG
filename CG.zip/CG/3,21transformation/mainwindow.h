#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include"cobject.h"
#include"transform.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    int n,flag;
    int xmid,ymid;
    cobject o1,o2;
    Transform tm;
    void inputObject();
    void displayObject();
    void paintEvent(QPaintEvent *);

    private slots:

        void on_ttranslate_clicked();

        void on_scale_clicked();

        void on_rotate_clicked();

        void on_shear_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
