#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QPainter>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    void paintEvent(QPaintEvent *);

    int w,h;        //width and height of main window
    double time;    //keeps track of the time elapsed
    int y;          //for vertical translation of folded flag
    int x;          //for horizontal translation of unfolding flag

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
