#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QPainter>
#include<QMouseEvent>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    count=0;
    ymin=999999;
    ymax=-999999;
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::mousePressEvent(QMouseEvent *event)
 {
    noOFEdges[count][0]=event->pos().x();
    noOFEdges[count][1]=event->pos().y();

    if(noOFEdges[count][1]<ymin)
    {
        ymin=noOFEdges[count][1];
    }


    if(noOFEdges[count][1]>ymax)
    {
        ymax=noOFEdges[count][1];
    }

    count++;

}


void MainWindow::paintEvent(QPaintEvent *)
 {
    QPainter painter(this);
    int i,curry,k,j;
    float xint[10],m[10];

    CEdge edge[10];

    for(i=0;i<count-1;i++)
     {
       edge[i].minput(noOFEdges[i][0],noOFEdges[i][1]);
       edge[i].minput2(noOFEdges[i+1][0],noOFEdges[i+1][1]);
    }

    edge[i].minput(noOFEdges[i][0],noOFEdges[i][1]);
    edge[i].minput2(noOFEdges[0][0],noOFEdges[0][1]);

    for(i=0;i<count-1;i++)
     {
       painter.drawLine(edge[i].getX1(),edge[i].getY1(),edge[i].getX2(),edge[i].getY2());
     }

     painter.drawLine(edge[i].getX1(),edge[i].getY1(),edge[i].getX2(),edge[i].getY2());

//*****************************TO FILL THE POLY***************************

     for(i=0;i<count;i++)
     {
         m[i]=edge[i].mcalc();
     }

     for(i=0;i<count;i++)
     {
        edge[i].sort();
     }

    for(i=0;i<count;i++)\
     {
         refx[i]=edge[i].getX1();
     }

//****************************ACTUAL CODE************************

     curry=ymax;

     while(curry >= ymin)
     {
         for(i=0;i<count;i++)
         {
             active[i]=-1;
             xint[i]=0;
         }

         j=0;
                                                                                //j->active edge,i->the no. of current edge
         for(i=0;i<count;i++)
         {
             if(curry>edge[i].getY2() && curry<=edge[i].getY1())
             {
                 active[j]=i;
                 j++;
             }
         }

         for(k=0;k<j;k++)
         {
             i=active[k];

             if(i==-1)
                 break;

             if(curry==edge[i].getY1())
                 xint[k]=edge[i].getX1();

             else xint[k]=refx[i] - m[i];
             refx[i]=xint[k];
          }

         int temp;

         for(i=0;i<j-1;i++)
         {
             for(k=i+1;k<j;k++)
            {
              if(xint[i]>xint[k])
              {
               temp=xint[i];
               xint[i]=xint[k];
               xint[k]=temp;
              }
             }
         }

         for(i=0;i<j-1;i+=2)
          {
            painter.drawLine(xint[i],curry,xint[i+1],curry);

          }

         curry--;
      }

}

void MainWindow::on_poly_clicked()
{
    update();
}

void MainWindow::on_clear_clicked()
{
    count=0;
    update();
}
