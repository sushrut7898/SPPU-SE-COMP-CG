#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui
{
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    int count,noOFEdges[10][2],active[10],ymin,ymax;
    float refx[10];
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();



public slots:

      void paintEvent(QPaintEvent *);
      void mousePressEvent(QMouseEvent *event);


private slots:
      void on_poly_clicked();

      void on_clear_clicked();

private:
    Ui::MainWindow *ui;
};

class CEdge
 {
   int x1,y1,x2,y2;

   float minv;

public:

   CEdge()
    {
      x1=0;
      y1=0;
      x2=0;
      y2=0;
      minv=0;
    }

   void minput(int x,int y)
    {
       x1=x;
       y1=y;
   }

   void minput2(int x,int y)
    {
       x2=x;
       y2=y;
   }

   int getX1()
    {
       return x1;
    }

   int getY1()
    {
       return y1;
    }



   int getX2()
    {
       return x2;
    }

   int getY2()
    {
       return y2;
    }

   void sort()
   {
     int temp;

     if(y1<y2)
    {
      temp=x1;
      x1=x2;
      x2=temp;

      temp=y1;
      y1=y2;
      y2=temp;
    }
  }

   float mcalc()
    {
       if(y1!=y2)
       {
           minv=float (x2-x1)/ float (y2-y1);
       }

       else minv=0;

       return minv;
   }


 };

#endif // MAINWINDOW_H
