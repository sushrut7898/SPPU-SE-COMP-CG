#include"circle.h"
#include"math.h"
#include"pixel.h"
#include<QPainter>


void circle::bresCircle(QPainter *painter,int r1,CPixel pix)
{
    int d;
    r=r1;
    d=3-2*r;
    x=0;
    y=r;

    int x1,y1;
    x1=pix.getX();
    y1=pix.getY();

    do
    {

        //draw8Point(&painter,x,y);
        painter->drawPoint(x1+x,y1+y);
        painter->drawPoint(x1+x,y1-y);
        painter->drawPoint(x1-x,y1+y);
        painter->drawPoint(x1-x,y1-y);
        painter->drawPoint(x1+y,y1+x);
        painter->drawPoint(x1-y,y1+x);
        painter->drawPoint(x1+y,y1-x);
        painter->drawPoint(x1-y,y1-x);
        if(d<0)
        {
            d=d+(4*x)+6;
        }
        else
        {
            d=d+(4*(x-y))+10;
            y--;
        }
        x++;
    }
    while(x<y);

}


void circle::draw8Point(QPainter *painter,int x1, int y1)
{
    painter->drawPoint(x1,y1);
    painter->drawPoint(x1,-y1);
    painter->drawPoint(-x1,y1);
    painter->drawPoint(-x1,-y1);
    painter->drawPoint(y1,x1);
    painter->drawPoint(-y1,x1);
    painter->drawPoint(y1,-x1);
    painter->drawPoint(-y1,-x1);
}
