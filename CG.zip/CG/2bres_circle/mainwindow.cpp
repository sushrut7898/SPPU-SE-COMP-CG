#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"pixel.h"
#include"circle.h"


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPen pen(Qt::blue,3,Qt::SolidLine,Qt::RoundCap);
    painter.setPen(pen);


    int x,y,r,xmid,ymid;
    x=ui->x1inp->text().toInt();
    y=ui->y1inp->text().toInt();
    r=ui->radius->text().toInt();

    xmid=this->width()/2;
    ymid=this->height()/2;

    CPixel pix;
    pix.putX(x+xmid);
    pix.putY(ymid-y);

    circle c;

    painter.drawLine(0,this->height()/2,this->width(),this->height()/2);
    painter.drawLine(this->width()/2,0,this->width()/2,this->height());

     QPen pen1(Qt::red,2,Qt::SolidLine,Qt::RoundCap);
     painter.setPen(pen1);


            c.bresCircle(&painter,r,pix);

}

void MainWindow::on_circle_clicked()
{
    update();
}
