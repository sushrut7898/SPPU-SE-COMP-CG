#ifndef CIRCLE_H
#define CIRCLE_H
#include<QPainter>
#include"pixel.h"

class circle
{
    int r,x,y;

public:

    void bresCircle(QPainter *painter,int r1,CPixel pix);
    void draw8Point(QPainter *painter,int x1,int y1);



};

#endif // CIRCLE_H
