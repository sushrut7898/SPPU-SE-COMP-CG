#ifndef PIXEL_H
#define PIXEL_H

class CPixel
{
    int x,y;
public:
    int getX()
    {
        return x;
    }
    int getY()
    {
        return y;
    }
    void putX(int a)
    {
        this->x=a;
    }
    void putY(int b)
    {
        this->y=b;
    }
};

#endif // PIXEL_H
