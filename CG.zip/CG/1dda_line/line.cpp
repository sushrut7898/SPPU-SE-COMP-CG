#include "line.h"
#include<math.h>

void line::dda_line(QPainter *painter,CPixel pix1,CPixel pix2)
{
    float x1,x2,y1,y2,dx,dy,xInc,yInc,x,y;
    int steps;

    x1=pix1.getX();
    x2=pix2.getX();
    y1=pix1.getY();
    y2=pix2.getY();

    x=x1;y=y1;

    dx=x2-x1;
    dy=y2-y1;

    if(abs(dx)>abs(dy))
        steps=abs(dx);
    else
        steps=abs(dy);

    xInc=dx/(float)steps;
    yInc=dy/(float)steps;

     painter->drawPoint(x+0.5,y+0.5);

    for(int i=0;i<steps;i++)
    {
        x+=xInc;
        y+=yInc;
         painter->drawPoint(x+0.5,y+0.5);
    }

}
