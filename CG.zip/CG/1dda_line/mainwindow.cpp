#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"line.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPen pen(Qt::blue,3,Qt::SolidLine,Qt::RoundCap);
    painter.setPen(pen);


    int x1,y1,x2,y2,xmid,ymid;
    x1=ui->x1inp->text().toInt();
    y1=ui->y1inp->text().toInt();
    x2=ui->x2inp->text().toInt();
    y2=ui->y2inp->text().toInt();

    xmid=this->width()/2;
    ymid=this->height()/2;

    CPixel p1,p2;
    p1.putX(x1+xmid);
    p1.putY(ymid-y1);
    p2.putX(x2+xmid);
    p2.putY(ymid-y2);

    line l1;

    painter.drawLine(0,this->height()/2,this->width(),this->height()/2);
    painter.drawLine(this->width()/2,0,this->width()/2,this->height());

     QPen pen1(Qt::red,2,Qt::SolidLine,Qt::RoundCap);
      painter.setPen(pen1);
    l1.dda_line(&painter,p1,p2);

}


void MainWindow::on_draw_clicked()
{
    update();
}
