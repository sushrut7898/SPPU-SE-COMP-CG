#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QPainter>
#include<QMouseEvent>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    int ymin,ymax,xmin,xmax;
    int cnt1,cnt2;
    int x1,y1,x2,y2;
    int flag;
    int code1,code2;
    int left=1,right=2,bottom=4,top=8;
    int getcode(int x1,int y1);

private:
    Ui::MainWindow *ui;

private slots:
    void on_rect_clicked();
    void on_line_clicked();
    void on_clip_clicked();

public slots:
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *);
};

#endif // MAINWINDOW_H
