#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"line.h"
#include"pixel.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    choice=0;
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_solid_clicked()
{
    choice=1;
    update();

}

void MainWindow::on_thick_clicked()
{
    choice=2;
    update();

}

void MainWindow::on_dot_clicked()
{
    choice=3;
    update();
}

void MainWindow::on_dash_clicked()
{
    choice=4;
    update();
}

void MainWindow::on_dsh_dot_clicked()
{
    choice=5;
    update();
}


void MainWindow::paintEvent(QPaintEvent *event)
{
      QPainter painter(this);
        QPen pen(Qt::blue,3,Qt::SolidLine,Qt::RoundCap);
        painter.setPen(pen);

        int x1,x2,y1,y2,w,xmid,ymid;

        x1=ui->x1->text().toInt();
        y1=ui->y1->text().toInt();
        x2=ui->x2->text().toInt();
        y2=ui->y2->text().toInt();


        xmid=this->width()/2;
        ymid=this->height()/2;

        CPixel p1,p2;
        p1.putX(x1+xmid);
        p1.putY(ymid-y1);
        p2.putX(x2+xmid);
        p2.putY(ymid-y2);

        line l1;

        painter.drawLine(0,this->height()/2,this->width(),this->height()/2);
        painter.drawLine(this->width()/2,0,this->width()/2,this->height());

         QPen pen1(Qt::red,1,Qt::SolidLine,Qt::RoundCap);
         painter.setPen(pen1);

        switch(choice)
        {
            case 1:
                l1.bres_line(&painter,p1,p2,1,1);
            break;
            case 2:
                w=ui->w->text().toInt();
                l1.bres_line(&painter,p1,p2,2,w);
            break;
            case 3:
                l1.bres_line(&painter,p1,p2,3,1);
            break;
             case 4:
                l1.bres_line(&painter,p1,p2,4,1);
            break;
            case 5:
                l1.bres_line(&painter,p1,p2,5,1);
            break;
         }
}
