#include"line.h"
#include"math.h"
#include"pixel.h"


void line::bres_line(QPainter *painter,CPixel pix1,CPixel pix2,int choice,int width)
{
    int x1,x2,y1,y2,dx,dy,dDx,dDy,x,y,d;
    float w;
    int s1=0,s2=0,intChange=0;

    x1=pix1.getX();
    x2=pix2.getX();
    y1=pix1.getY();
    y2=pix2.getY();

    x=x1;y=y1;

    dx=abs(x2-x1);
    dy=abs(y2-y1);

    if(x1>x2)
        s1=-1;
    else if(x2>x1)
        s1=1;
    if(y1>y2)
        s2=-1;
    else if(y2>y1)
        s2=1;

    if(dy>dx)
    {
        swap(dx,dy);
        intChange=1;
    }

    w=((width-1)*(sqrt((dx*dx)+(dy*dy))))/(2*dx);

    dDx=2*dx;
    dDy=2*dy;
    d=dDy-dx;

    int n;


    switch(choice)
    {



        case 1:
            for(int i=0;i<=dx;i++)
            {

                painter->drawPoint(x,y);
                while(d>0)
                {
                    if(intChange==1)
                        x=x+s1;
                    else
                        y=y+s2;
                    d=d-dDx;
                }
                if(intChange==1)
                    y=y+s2;
                else
                    x=x+s1;
                d=d+dDy;
            }
            break;




        case 2:
            for(int i=0;i<=dx;i++)
            {

                painter->drawPoint(x,y);
                if(intChange==0)
                {
                    for(int j=1;j<=w;j++)
                    {
                        painter->drawPoint(x,y+j);
                        painter->drawPoint(x,y-j);
                    }
                }
                else
                {
                    for(int j=1;j<=w;j++)
                    {
                        painter->drawPoint(x+j,y);
                        painter->drawPoint(x-j,y);
                    }
                }
                while(d>0)
                {
                    if(intChange==1)
                        x=x+s1;
                    else
                        y=y+s2;
                    d=d-dDx;
                }
                if(intChange==1)
                    y=y+s2;
                else
                    x=x+s1;
                d=d+dDy;
            }
                break;



      case 3:
            for(int i=0;i<=dx;i++)
            {

                n=4;
                if(i%n<2)
                    painter->drawPoint(x,y);
                while(d>0)
                {
                    if(intChange==1)
                        x=x+s1;
                    else
                        y=y+s2;
                    d=d-dDx;
                }
                if(intChange==1)
                    y=y+s2;
                else
                    x=x+s1;
                d=d+dDy;
            }
                break;



      case 4:
            for(int i=0;i<=dx;i++)
            {

                n=6;
                if(i%n<4)
                    painter->drawPoint(x,y);
                while(d>0)
                {
                    if(intChange==1)
                        x=x+s1;
                    else
                        y=y+s2;
                    d=d-dDx;
                }
                if(intChange==1)
                    y=y+s2;
                else
                    x=x+s1;
                d=d+dDy;
            }
                break;



       case 5:
            for(int i=0;i<=dx;i++)
            {

                n=13;
                if(i%n<7||i%n==9||i%n==10)
                    painter->drawPoint(x,y);
                while(d>0)
                {
                    if(intChange==1)
                        x=x+s1;
                    else
                        y=y+s2;
                    d=d-dDx;
                }
                if(intChange==1)
                    y=y+s2;
                else
                    x=x+s1;
                d=d+dDy;
            }
                break;

    }

}

void line::swap(int &a,int &b)
{
    int temp;
    temp=a;
    a=b;
    b=temp;
}
