#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    int choice;
    void paintEvent(QPaintEvent *event);

private slots:
    void on_solid_clicked();

    void on_thick_clicked();

    void on_dot_clicked();

    void on_dash_clicked();

    void on_dsh_dot_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
