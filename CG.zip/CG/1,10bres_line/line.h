#ifndef LINE_H
#define LINE_H


#include "pixel.h"
#include<QPainter>

class line
{
    CPixel pix1,pix2;
public:
    void bres_line(QPainter *painter,CPixel pix1,CPixel pix2,int choice,int width);
    void swap(int &a,int &b);
};

#endif // LINE_H
