#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QPainter"
#include <QInputDialog>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    inputObject();

    ui->setupUi(this);

}

MainWindow::~MainWindow()
{
    delete ui;
}
Cobject o1 ,o2 , o3 ;
int tx , ty , flag=0 ,sx,sy;

void MainWindow::inputObject()
{
    int temp[10][3],n;
    n=QInputDialog::getInt(this,"object","Enter No of Vertices");
    for(int i=0;i<n;i++)
    {
        temp[i][0]=QInputDialog :: getInt(this , "object" , "Enter X coordinate" ) ;
        temp[i][1]=QInputDialog :: getInt(this , "object" ,  "Enter Y coordinate") ;
        temp[i][2]=1;
    }

   o1.setXY(temp,n);

}

void Cobject::displayObject(QPainter *painter)
{
    int i;
    for(i=0;i<n-1;i++)
    {
        painter->drawLine(XY[i][0],XY[i][1],XY[i+1][0],XY[i+1][1]);
    }

    painter->drawLine(XY[i][0],XY[i][1],XY[0][0],XY[0][1]);

}

void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    o1.displayObject(&painter);

    Translate(&painter);


}

void MainWindow ::Translate(QPainter *painter)
{
    int T[3][3] ;
    tx = ui->Tx->toPlainText().toInt();
    ty = ui->Ty->toPlainText().toInt();
    for(int i=0 ; i<3 ; i++)
    {
          for (int j=0 ; j<3 ; j++)
          {
              if(i==j)
              {
                  T[i][j] = 1 ;
              }
              else if (i==2 && j==0)
              {
                  T[i][j] = tx ;
              }
              else if (i==2 && j==1)
              {
                  T[i][j] = ty ;
              }
              else
              {
                  T[i][j] = 0 ;
              }
          }
    }
    o2.setXY(T ,3);
    o3 = o1 * o2 ;
    o3.displayObject(painter) ;
}





void MainWindow::on_Trans_clicked()
{
    update();
}

