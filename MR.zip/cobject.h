#ifndef COBJECT_H
#define COBJECT_H
#include"QPainter"

class Cobject
{
public:
    Cobject();
    int XY[10][3],n;
    void setXY(int X[10][3],int n1);
    Cobject operator* ( Cobject ) ;
     void displayObject(QPainter *);
};


#endif // COBJECT_H
