#include "cobject.h"

Cobject::Cobject()
{

}

void Cobject::setXY(int X[10][3], int n1)
{
    n = n1;
    for (int i= 0 ; i< n ; i++)
    {
        for(int j=0 ; j< 3 ;j++)
        {
           XY[i][j]=X[i][j];
        }
    }
}

Cobject Cobject :: operator* (Cobject o2)
{
    Cobject o3 ;
    int t[n][3];
    for(int i = 0; i < n; ++i)
            for(int j = 0; j < 3; ++j)
            {
                t[i][j]=0;
                for(int k = 0; k < 3; ++k)
                {
                    t[i][j]=t[i][j]+ (XY[i][k] * o2.XY[k][j]);
                }
             }
                o3.setXY(t,n);
        return o3 ;
}



