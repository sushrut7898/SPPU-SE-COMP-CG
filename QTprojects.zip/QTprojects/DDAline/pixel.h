#ifndef PIXEL_H
#define PIXEL_H


class Cpixel
{
public:
    int x,y;
    void set_x(int a)
    {
        this->x=a;
    }
    void set_y(int b)
    {
        this->y=b;
    }
    int get_x()
    {
        return x;
    }
    int get_y()
    {
        return y;
    }
};
#endif // PIXEL_H
