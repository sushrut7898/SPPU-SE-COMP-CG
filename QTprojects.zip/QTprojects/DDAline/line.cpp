#include "line.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include "pixel.h"
#include "math.h"

void line::draw_Line(QPainter *painter, Cpixel p1, Cpixel p2)
 {
     float x1,y1,x2,y2,xinc,yinc;
     x1=p1.get_x();
     y1=p1.get_y();
     x2=p2.get_x();
     y2=p2.get_y();
     int dx=x2-x1;
     int dy=y2-y1;

     int steps,i;

     if(abs(dx)>abs(dy))
     {
         steps=abs(dx);
     }
     else
         steps=abs(dy);

     xinc=(dx)/(float)steps;
     yinc=(dy)/(float)steps;
     painter->drawPoint(round(x1),round(y1));


     for(i=0;i<steps;i++)
     {
         x1+=xinc;
         y1+=yinc;
         painter->drawPoint(round(x1),round(y1));
     }
}
void line::draw_Line(QPainter *painter, Cpixel p1, Cpixel p2 , int w)
{
    int s1,s2,x1,x2,y1,y2,dx,dy,intChange=0;
    x1=p1.get_x();
    y1=p1.get_y();
    x2=p2.get_x();
    y2=p2.get_y();
    dx=abs(x2-x1);
    dy=abs(y2-y1);
    if(x1<x2)
        s1=1;
    else if(x1==x2)
        s1=0;
    else if(x1>x2)
        s1=-1;
    if(y1<y2)
        s2=1;
    else if(y1==y2)
        s2=0;
    else if(y1>y2)
        s2=-1;
    if(dx<dy)
    {
        intChange=1;
        int temp=dx;
        dx=dy;
        dy=temp;
    }
    int e1=2*dx;
    int e2=2*dy;
    int e=(2*dy)-dx;
    for(int i=1;i<=dx;i++)
    {
        painter->drawPoint(x1,y1);
        while(e>0)
        {
            if(intChange==1)
                x1=x1+s1;
            else
                y1=y1+s2;
            e=e-(2*dx);
        }
        if(intChange==1)
            y1=y1+s2;
        else
            x1=x1+s1;
        e=e+e2;
       // painter->drawPoint(x1,y1);
    }
}

