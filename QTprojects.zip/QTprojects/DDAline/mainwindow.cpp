#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include "pixel.h"
#include "line.h"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}
int flag;
void MainWindow::on_pushButton_clicked()
{
    flag=1;
    update();
}
void MainWindow :: paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    int x1,y1,x2,y2;
    line l1,l2;
    Cpixel pix,pix2;
    x1=ui->x1Input->text().toInt();
     y1=ui->y1Input->text().toInt();
     x2=ui->x2Input->text().toInt();
     y2=ui->y2Input->text().toInt();
       pix.set_x(x1);
       pix.set_y(y1);
       pix2.set_x(x2);
       pix2.set_y(y2);
        if(flag==1)
       l1.draw_Line(&painter,pix,pix2);
        else
       l2.draw_Line(&painter,pix,pix2,5);
}
MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_2_clicked()
{
    flag=2;
    update();
}
