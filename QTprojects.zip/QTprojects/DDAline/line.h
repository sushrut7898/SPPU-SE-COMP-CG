#ifndef LINE_H
#define LINE_H
#include<pixel.h>
#include<QPainter>

class line
{
public:
void draw_Line(QPainter *painter,Cpixel p1,Cpixel p2);
void draw_Line(QPainter *painter,Cpixel p1,Cpixel p2, int w);
};

#endif // LINE_H
