#ifndef BRESENHAM_H
#define BRESENHAM_H


class Bresenham
{
public:
    Bresenham();
};

#endif // BRESENHAM_H