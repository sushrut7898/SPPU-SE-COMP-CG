#include"pixel.h"

void pixel::setx(int a)
{
    x=a;
}
void pixel::sety(int b)
{
    y=b;
}
int pixel::getx()
{
    return x;
}
int pixel::gety()
{
    return y;
}
