#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"qpainter.h"
#include"pixel.h"
#include"circle.h"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_Circle_clicked()
{
    update();
}

void MainWindow::paintEvent(QPaintEvent *)
{
    int w,h,x,y,r;
    QPainter painter(this);
    w=this->width();
    h=this->height();
    QPen pen(Qt::green,1,Qt::SolidLine,Qt::RoundCap);
    painter.setPen(pen);
    painter.drawLine(w/2,0,w/2,h);
    painter.drawLine(0,h/2,w,h/2);

    x=ui->xinput->text().toInt();
    y=ui->yinput->text().toInt();
    r=ui->radiusinput->text().toInt();

    x=x+w/2;
    y=h/2-y;

    pixel p;
    p.setx(x);
    p.sety(y);

    circle c;
    c.drawcircle(&painter,p,r);
}
