#include"circle.h"

void circle::drawcircle(QPainter *painter, pixel p1, int r)
{
    int xc,yc;
    float x,y,e;
    xc=p1.getx();
    yc=p1.gety();

        x=0;
        y=r;
        e=3-(2*r);
    QPen pen(Qt::red,1,Qt::SolidLine,Qt::RoundCap);
    painter->setPen(pen);
        do{

            painter->drawPoint(x+xc,y+yc);
            painter->drawPoint(y+xc,x+yc);
            painter->drawPoint(y+xc,-x+yc);
            painter->drawPoint(x+xc,-y+yc);
            painter->drawPoint(-x+xc,-y+yc);
            painter->drawPoint(-y+xc,-x+yc);
            painter->drawPoint(-y+xc,x+yc);
            painter->drawPoint(-x+xc,y+yc);

            if(e<0)
            {
                e=e+4*x+6;
            }

            else {

                e=e+4*(x-y)+10;
                y=y-1;
            }

            x=x+1;
        }while(x<y);
}
