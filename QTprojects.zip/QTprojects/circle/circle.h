#ifndef CIRCLE
#define CIRCLE
#include"qpainter.h"
#include"pixel.h"
class circle
{
   public:
    void drawcircle(QPainter *,pixel,int);
};

#endif // CIRCLE

