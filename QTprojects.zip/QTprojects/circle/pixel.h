#ifndef PIXEL
#define PIXEL
class pixel
{
    int x,y;
public:
    void setx(int);
    void sety(int);
    int getx();
    int gety();
};

#endif // PIXEL

