#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QMouseEvent>
#include<QPainter>
#include<QThread>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    update();
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    noOfEdges[count][0]=event->pos().x();
    noOfEdges[count][1]=event->pos().y();
    count++;
}

void MainWindow::paintEvent(QPaintEvent *s)
{

    QPainter painter(this);

    ui->horizontalSlider->setRange(0,10);

    if(colorFlag==1)
    {
        QPen pen(Qt::red,penSize,Qt::SolidLine,Qt::RoundCap);
        painter.setPen(pen);
    }
    else if(colorFlag==2)
    {
        QPen pen(Qt::blue,penSize,Qt::SolidLine,Qt::RoundCap);
        painter.setPen(pen);
    }
    //
    for(int i=0;i<10;i++)
        {
            ed[i]=edges[i];
        }
    //
       drawObject(&painter);
    //
       if(flag==1)
    {
        scanLine(&painter);
        for(int j=0;j<count;j++)
           {
            noOfEdges[j][0]=0;
            noOfEdges[j][1]=0;
           }
        count=0;
        flag=0;
    }
}

void MainWindow::drawObject(QPainter *painter)
{
    int l;
    for(l=0;l<(count-1);l++)
    {
        edges[l].mInput(noOfEdges[l][0],noOfEdges[l][1]);
        edges[l].mInput2(noOfEdges[l+1][0],noOfEdges[l+1][1]);
        painter->drawLine(edges[l].getx1(),edges[l].gety1(),edges[l].getx2(),edges[l].gety2());
    }
    edges[l].mInput(noOfEdges[l][0],noOfEdges[l][1]);
    edges[l].mInput2(noOfEdges[0][0],noOfEdges[0][1]);
    painter->drawLine(edges[l].getx1(),edges[l].gety1(),edges[l].getx2(),edges[l].gety2());
}

void MainWindow::scanLine(QPainter *ptr)
{
    for(int i=0;i<count;i++)
    {
       edges[i].sortOnY();
    }
    for(int i=0;i<count;i++)
    {
       m[i]=edges[i].mCalculate();
    }
    for(int i=0;i<count;i++)
    {
       refX[i]=edges[i].getx1();
    }
    //Calculation of Ymin
    for(int i=0;i<count;i++)
    {
        if(Ymin>=edges[i].gety2())
            Ymin=edges[i].gety2();
    }
    //Calculation of Ymax
    for(int i=0;i<count;i++)
    {
        if(Ymax<=edges[i].gety1())
            Ymax=edges[i].gety1();
    }
    curr_Y=Ymax;
    int i,j,k;
    //Marking active edges

    while(curr_Y>=Ymin)
    {

            for(i=0;i<count;i++)
            {
            active[i]=-1;
            x_int[i]=0;
            }
            j=0;
            for(i=0;i<count;i++)
            {
                if((curr_Y>edges[i].gety2())&&(curr_Y<=edges[i].gety1()))
                    {
                        active[j]=i;
                        j++;
                    }
            }
            for(k=0;k<j;k++)
            {
                i=active[k];

            if(i==-1)
                break;

            if(curr_Y==edges[i].gety1())
                x_int[k]=edges[i].getx1();
            else
            {
                x_int[k]=refX[i]+(-edges[i].mCalculate());
                refX[i]=x_int[k];
            }
            }
            float temp;//variable used for swapping, below
            //Sorting x_int array
            for(int a=0;a<k;a++)
            {
                for(int b=0;b<k-a-1;b++)
                {
                    if(x_int[b]>x_int[b+1])
                    {
                        temp=x_int[a];
                        x_int[a]=x_int[b];
                        x_int[b]=temp;
                    }
                }
            }

            //Extracting X to draw scan line
    for(int t=0;t<j-1;t=t+2)
    {
        ptr->drawLine(x_int[t],curr_Y,x_int[t+1],curr_Y);
    }
    curr_Y--;    }
}

void MainWindow::on_pushButton_2_clicked()
{
    flag=1;
    update();
}

void MainWindow::on_redFill_toggled(bool checked)
{
    colorFlag=1;
    update();
}

void MainWindow::on_blueFill_toggled(bool checked)
{
    colorFlag=2;
    update();
}

void MainWindow::on_horizontalSlider_valueChanged(int value)
{
    penSize=ui->horizontalSlider->value();
    update();
}
