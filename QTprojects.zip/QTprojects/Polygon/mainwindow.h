#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class CEdge
{
public:
    int x1,x2,y1,y2;
    float mInv;
    CEdge()
    {
        x1=0;
        x2=0;
        y1=0;
        y2=0;
        mInv=0;
    }
    void mInput(int x,int y)
    {
        x1=x;
        y1=y;
    }
    void mInput2(int x, int y)
    {
        x2=x;
        y2=y;
    }
    int getx1(){return x1;}
    int gety1(){return y1;}
    int getx2(){return x2;}
    int gety2(){return y2;}

    float mCalculate()
    {
        int dx,dy;
        if(y1!=y2)
        {
            dx=x2-x1;
            dy=y2-y1;
            mInv=(float)dx/(float)dy;
            return (mInv);
        }
        else
            return(0);
    }

    void sortOnY()
    {
        int temp;
        if(y1<y2)
        {
            temp=y1;
            y1=y2;
            y2=temp;
            temp=x1;
            x1=x2;
            x2=temp;
        }
    }

};
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void drawObject(QPainter *p);


public slots:
    void paintEvent(QPaintEvent *s);
    void mousePressEvent(QMouseEvent *event);

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_redFill_toggled(bool checked);

    void on_blueFill_toggled(bool checked);

    void on_horizontalSlider_valueChanged(int value);

private:
    Ui::MainWindow *ui;
    int count=0;
    int noOfEdges[10][2];
    int flag=0;
    int colorFlag=0;
    int penSize=0;
    float refX[10], m[10];
    int active[10];
    int curr_Y;
    int Ymin=999;
    int Ymax=0;
    int yCos[10];
    float x_int[10];
    void scanLine(QPainter *);
    CEdge edges[10],ed[10];

};



#endif // MAINWINDOW_H
