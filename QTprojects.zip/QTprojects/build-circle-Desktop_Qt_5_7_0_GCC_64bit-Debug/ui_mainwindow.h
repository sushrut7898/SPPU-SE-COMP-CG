/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *centrecoodinates;
    QLabel *x;
    QLabel *y;
    QLineEdit *xinput;
    QLineEdit *yinput;
    QLabel *radius;
    QLineEdit *radiusinput;
    QPushButton *Circle;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(688, 404);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        centrecoodinates = new QLabel(centralWidget);
        centrecoodinates->setObjectName(QStringLiteral("centrecoodinates"));
        centrecoodinates->setGeometry(QRect(40, 50, 181, 31));
        QFont font;
        font.setPointSize(14);
        font.setItalic(true);
        font.setUnderline(true);
        centrecoodinates->setFont(font);
        x = new QLabel(centralWidget);
        x->setObjectName(QStringLiteral("x"));
        x->setGeometry(QRect(70, 90, 67, 17));
        y = new QLabel(centralWidget);
        y->setObjectName(QStringLiteral("y"));
        y->setGeometry(QRect(70, 110, 67, 17));
        xinput = new QLineEdit(centralWidget);
        xinput->setObjectName(QStringLiteral("xinput"));
        xinput->setGeometry(QRect(100, 80, 41, 27));
        yinput = new QLineEdit(centralWidget);
        yinput->setObjectName(QStringLiteral("yinput"));
        yinput->setGeometry(QRect(100, 110, 41, 27));
        radius = new QLabel(centralWidget);
        radius->setObjectName(QStringLiteral("radius"));
        radius->setGeometry(QRect(50, 150, 67, 17));
        radiusinput = new QLineEdit(centralWidget);
        radiusinput->setObjectName(QStringLiteral("radiusinput"));
        radiusinput->setGeometry(QRect(100, 140, 41, 27));
        Circle = new QPushButton(centralWidget);
        Circle->setObjectName(QStringLiteral("Circle"));
        Circle->setGeometry(QRect(70, 180, 99, 27));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 688, 25));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        centrecoodinates->setText(QApplication::translate("MainWindow", "Centre co-ordinates:", 0));
        x->setText(QApplication::translate("MainWindow", "x", 0));
        y->setText(QApplication::translate("MainWindow", "y", 0));
        radius->setText(QApplication::translate("MainWindow", "radius", 0));
        Circle->setText(QApplication::translate("MainWindow", "Draw Circle", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
