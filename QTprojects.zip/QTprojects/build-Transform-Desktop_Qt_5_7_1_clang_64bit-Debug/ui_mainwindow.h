/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QPushButton *pushButton;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *TX;
    QLineEdit *TY;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *SX;
    QLineEdit *SY;
    QLabel *label_5;
    QPushButton *pushButton_4;
    QLineEdit *Theta;
    QLineEdit *shx;
    QLabel *label_6;
    QPushButton *pushButton_5;
    QLabel *label_7;
    QLineEdit *shy;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(826, 458);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(350, 160, 113, 32));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(50, 230, 60, 16));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(50, 250, 60, 16));
        TX = new QLineEdit(centralWidget);
        TX->setObjectName(QStringLiteral("TX"));
        TX->setGeometry(QRect(70, 230, 113, 21));
        TY = new QLineEdit(centralWidget);
        TY->setObjectName(QStringLiteral("TY"));
        TY->setGeometry(QRect(70, 250, 113, 21));
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(70, 280, 113, 32));
        pushButton_3 = new QPushButton(centralWidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(250, 280, 113, 32));
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(210, 240, 60, 16));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(210, 260, 60, 16));
        SX = new QLineEdit(centralWidget);
        SX->setObjectName(QStringLiteral("SX"));
        SX->setGeometry(QRect(250, 230, 113, 21));
        SY = new QLineEdit(centralWidget);
        SY->setObjectName(QStringLiteral("SY"));
        SY->setGeometry(QRect(250, 250, 113, 21));
        label_5 = new QLabel(centralWidget);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(400, 240, 60, 16));
        pushButton_4 = new QPushButton(centralWidget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(450, 280, 113, 32));
        Theta = new QLineEdit(centralWidget);
        Theta->setObjectName(QStringLiteral("Theta"));
        Theta->setGeometry(QRect(450, 240, 113, 21));
        shx = new QLineEdit(centralWidget);
        shx->setObjectName(QStringLiteral("shx"));
        shx->setGeometry(QRect(650, 230, 113, 21));
        label_6 = new QLabel(centralWidget);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(610, 260, 60, 16));
        pushButton_5 = new QPushButton(centralWidget);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(650, 280, 113, 32));
        label_7 = new QLabel(centralWidget);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(610, 240, 60, 16));
        shy = new QLineEdit(centralWidget);
        shy->setObjectName(QStringLiteral("shy"));
        shy->setGeometry(QRect(650, 250, 113, 21));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 826, 22));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        pushButton->setText(QApplication::translate("MainWindow", "Draw", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "tx:", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "ty:", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("MainWindow", "Translate", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("MainWindow", "Scale", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "Sx:", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "Sy:", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "THETA:", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("MainWindow", "Rotate", Q_NULLPTR));
        label_6->setText(QApplication::translate("MainWindow", "ShY:", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("MainWindow", "Shear", Q_NULLPTR));
        label_7->setText(QApplication::translate("MainWindow", "ShX:", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
