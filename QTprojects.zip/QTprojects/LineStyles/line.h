#ifndef LINE_H
#define LINE_H
#include "pixel.h"
class CLine {
    public:
    CPixel p1, p2;
    void draw_line(QPainter *painter, CPixel pix1, CPixel pix2, float flag);
    void draw_line1(QPainter *painter, CPixel pix1, CPixel pix2);
    void draw_line2(QPainter *painter, CPixel pix1, CPixel pix2);
    void draw_line3(QPainter *painter, CPixel pix1, CPixel pix2);
    void draw_line(QPainter *painter, CPixel pix1, CPixel pix2, int w);
    void draw_line(QPainter *painter, int x1, int y1, int x2, int y2, float flag);
};


#endif // LINE_H
