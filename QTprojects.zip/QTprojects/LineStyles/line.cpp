#include "line.h"
#include <QPainter>
#include <math.h>


// drawLine function draws thick pixel
void drawLine(QPainter *painter, int x, int y, int w, int intCh)
{
    int i=0;
    //To draw green line
   //QColor::setcolor(0,255,0);
    if(intCh == 0)
        for (i=0; i<w; i++)
        {
            painter->drawPoint(painter->window().width() / 2  + x,
                               painter->window().height() / 2 - y+i);
            painter->drawPoint(painter->window().width() / 2  + x,
                               painter->window().height() / 2 - y -i);
        }
    else
         for (i=0; i<w; i++)
        {
            painter->drawPoint(painter->window().width() / 2  + x+i,
                               painter->window().height() / 2 - y);
            painter->drawPoint(painter->window().width() / 2  + x-i,
                               painter->window().height() / 2 - y);
        }
}


//function for DDA line algorithm
void CLine::draw_line(QPainter *painter, CPixel pix1, CPixel pix2, float flag)
{
    int steps,i;
    int x1=pix1.getX(),y1=pix1.getY(),x2=pix2.getX(),y2=pix2.getY();
    float dx=0, dy=0, xincr, yincr;
    float x,y;
    x=x1; y=y1;

    dx = x2 - x1;
    dy = y2 - y1;

    if(abs(dx) > abs(dy))
        steps = abs(dx);
    else
        steps = abs(dy);

    xincr = dx / (float)steps;
    yincr = dy / (float)steps;

    i = 1;

    //setcolor(255,0,0);   //RED

    if(flag == 1){

        do
        {
            x = x + xincr;
            y = y + yincr;
            i++;
            if ( (i % 2) != 0 ) //For dotted line, plot alternate pixels
                painter->drawPoint(painter->window().width() / 2  + x + 0.5,
                                   painter->window().height() / 2 - y + 0.5);
        }while(i <= steps);

    }

    else if(flag == 2){
        do
        {
            x = x + xincr;
            y = y + yincr;
            i++;
            if ( (i % 5) != 0 ) //For dash line
                painter->drawPoint(painter->window().width() / 2  + x + 0.5,
                                   painter->window().height() / 2 - y + 0.5);
        }while(i <= steps);
    }
    else if(flag == 3){
        do
        {
            x = x + xincr;
            y = y + yincr;
            i++;
            if ( (i % 2) != 0 || (i %3 ) == 0) //For dash dot line
                painter->drawPoint(painter->window().width() / 2  + x + 0.5,
                                   painter->window().height() / 2 - y + 0.5);
        }while(i <= steps);
    }
    else if(flag == 4){

        do
        {
            x = x + xincr;
            y = y + yincr;
            i++;
            if ( (i % 2) != 0 || (i%3) == 0 || (i%5) == 0) //For dash dot line
                painter->drawPoint(painter->window().width() / 2  + x + 0.5,
                                   painter->window().height() / 2 - y + 0.5);
        }while(i <= steps);

    }
    else{
        do
        {
            x = x + xincr;
            y = y + yincr;
            i++;
            if (1) //For solid line (Axes)
                painter->drawPoint(painter->window().width() / 2  + x + 0.5,
                                   painter->window().height() / 2 - y + 0.5);
        }while(i <= steps);
    }

}

void CLine::draw_line(QPainter *painter1, int x1, int y1, int x2, int y2, float x= 0 )
{
    CPixel pt1, pt2;
    pt1.setX(x1);pt1.setY(y1);
    pt2.setX(x2);pt2.setY(y2);
    draw_line(painter1, pt1, pt2, x);
}

