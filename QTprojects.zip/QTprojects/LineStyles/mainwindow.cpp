#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "pixel.h"
#include <QPainter>

#include "line.h"


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
float MainWindow :: flag = 0;

void MainWindow::paintEvent(QPaintEvent *)
{

    CPixel p1, p2;
    CLine  different_lines;


    int x1,y1,x2,y2;

    QPainter painter(this);
    QPen p(Qt::blue, 1, Qt::SolidLine, Qt::RoundCap);
    painter.setPen(p);

    //Divide screen into four quadrants
        // Vertical Line
        different_lines.draw_line(&painter, 0, this->height() / 2,
                                  0, -(this->height()/2), 0);
        //Horizontal Line
        different_lines.draw_line(&painter,- (this->width()/ 2), 0 ,
                                  this->width()/ 2, 0, 0);



    x1=this->ui->x1->text().toInt();
    y1=this->ui->y1->text().toInt();
    x2=this->ui->x2->text().toInt();
    y2=this->ui->y2->text().toInt();

//Start Point
    p1.setX(x1);
    p1.setY(y1);

//End Point
    p2.setX(x2);
    p2.setY(y2);


    if(flag > 0){
        QPen p(Qt::red, 1, Qt::SolidLine, Qt::RoundCap);
        painter.setPen(p);
    }

        different_lines.draw_line(&painter,p1,p2, flag);//DDA all


}

void MainWindow::on_DottedLine_clicked()
{
    flag = 1;
    update();
}


void MainWindow::on_DashLine_clicked()
{
    flag = 2;
    update();
}

void MainWindow::on_DashDotLine_clicked()
{
    flag = 3;
    update();
}

void MainWindow::on_CustomLine_clicked()
{
    flag = 4;
    update();
}

void MainWindow::on_actionDot_triggered()
{
    flag = 1;
    update();
}

void MainWindow::on_actionDash_triggered()
{
    flag=2;
    update();
}

void MainWindow::on_actionDot_Dash_triggered()
{
    flag = 3;
    update();
}

void MainWindow::on_actionCustom_triggered()
{
    flag = 4;
    update();
}
