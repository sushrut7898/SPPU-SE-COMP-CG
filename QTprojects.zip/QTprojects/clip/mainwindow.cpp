#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QPainter>
#include<QMouseEvent>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    cnt1=cnt2=0;
    flag=1;
    code1=code2=0;
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if(flag==1)
    {   if(cnt1==0)
        {
            xmin=event->pos().x();
            ymin=event->pos().y();
            cnt1++;
        }
        else
        {
            xmax=event->pos().x();
            ymax=event->pos().y();
            cnt1=0;
        }
    }
    if(flag==2)
    {
        if(cnt2==0)
        {
            x1=event->pos().x();
            y1=event->pos().y();
            cnt2++;
            code1=getcode(x1,y1);
        }
        else
        {
            x2=event->pos().x();
            y2=event->pos().y();
            cnt2=0;
            code2=getcode(x2,y2);
        }

    }
}

int MainWindow::getcode(int x1,int y1)
{
    int code=0;
    if(x1>xmax)
        code=code|right;
    if(x1<xmin)
        code=code|left;
    if(y1<ymin)
        code=code|top;
    if(y1>ymax)
        code=code|bottom;
    return code;
}

void MainWindow::on_rect_clicked()
{
    flag=2;
    update();
}
void MainWindow::on_line_clicked()
{
    flag=2;
    update();
}
void MainWindow::on_clip_clicked()
{
    flag=3;
    update();
}


void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPen pen(Qt::black,2,Qt::SolidLine,Qt::RoundCap);
    painter.setPen(pen);

    painter.drawRect(xmin,ymin,xmax-xmin,ymax-ymin);

    if(flag==2)
    {
        painter.drawLine(x1,y1,x2,y2);
    }
    if(flag==3)
    {

        while(1)
        {
        float m=(float)(y2-y1)/(x2-x1);
        if(code1==0&&code2==0)
        {
            painter.drawLine(x1,y1,x2,y2);
            return;
        }
        else if((code1&code2)!=0)
        {
            break;
        }
        else
        {

            int temp;
            if(code1==0)
                temp=code2;
            else
                temp=code1;

            int x,y;

            if(temp & top)
            {
                x = x1+ (ymin-y1)/m;
                y = ymin;
            }
            else if(temp & bottom)
            {
                x = x1+ (ymax-y1)/m;
                y = ymax;
            }
            else if(temp & left)
            {
                x = xmin;
                y = y1+ m*(xmin-x1);
            }
            else if(temp & right)
            {
                x = xmax;
                y = y1+ m*(xmax-x1);
            }
            if(temp == code1)
            {
                x1 = x;
                y1 = y;
                code1 = getcode(x1,y1);
            }
            else
            {
                x2 = x;
                y2 = y;
                code2 = getcode(x2,y2);
            }
        }
        }
    }
}


