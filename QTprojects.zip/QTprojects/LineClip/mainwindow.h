#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>


class LineClip
{
public:
    int rect[2][2];
    int line[2][2];
    int clippedLine[2][2];
    int OutCode1=0000;
    int OutCode2=0000;
    int x1,y1,x2,y2;
    int xMax,xMin,yMax,yMin;
};

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT


public slots:
    void paintEvent(QPaintEvent *s);
    void mousePressEvent(QMouseEvent *event);

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    int temp[4][2];
    int count=0;
    int flag=0;
    LineClip l1;
    void drawWind(LineClip , QPainter *);
    void findInt(LineClip );
    void setOutcode(LineClip);
    void draw_Line(QPainter *painter,LineClip l);

private slots:
    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
