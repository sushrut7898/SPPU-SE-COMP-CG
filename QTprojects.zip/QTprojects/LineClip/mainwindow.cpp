#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QPainter>
#include<QMouseEvent>
#include<math.h>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    temp[count][0]=event->pos().x();
    temp[count][1]=event->pos().y();
    count++;
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
        QPainter painter(this);
    for(int i=0;i<count;i++)
    {
        l1.rect[i][0]=temp[i][0];
        l1.rect[i][1]=temp[i][1];
    }
    for(int i=2;i<count;i++)
    {
        l1.line[i-2][0]=temp[i][0];
        l1.line[i-2][1]=temp[i][1];
    }
    drawWind(l1, &painter);

    l1.x1=l1.line[0][0];
    l1.x2=l1.line[1][0];
    l1.y1=l1.line[0][1];
    l1.y2=l1.line[1][1];
    l1.xMin=l1.rect[0][0];
    l1.xMax=l1.rect[1][0];
    l1.yMin=l1.rect[0][1];
    l1.yMax=l1.rect[1][1];

    draw_Line(&painter, l1);

}

//---------------------------------------------------------------------------------------------------------------------

void MainWindow::drawWind(LineClip l, QPainter *ptr)
{
    int w,h;
    w=(l.rect[1][0]-l.rect[0][0]);
    h=(l.rect[1][1]-l.rect[0][1]);


    QPen pen(Qt::black,5,Qt::SolidLine,Qt::RoundCap);
    ptr->setPen(pen);

    ptr->drawRect(l.rect[0][0],l.rect[0][1],w,h);

    if(flag==1)
    {
        for(int i=0;i<count;i++)
        {
            temp[i][0]=temp[i][1]=0;
            count=0;
        }
    }
}

//---------------------------------------------------------------------------------------------------------------------

void MainWindow::findInt(LineClip l)
{
    int dy,dx;
    float m;
    dx=l.x1-l.x2;
    dy=l.y1-l.y2;
    m=(float)dy/(float)dx;

}

//---------------------------------------------------------------------------------------------------------------------

void MainWindow::setOutcode(LineClip l)
{
    //Setting Outcode for(x1,y1)
    if(l.y1>l.yMax)
    {
        l.OutCode1=l.OutCode1+1000;
    }
    if(l.y1<l.yMin)
    {
        l.OutCode1=l.OutCode1+100;
    }
    if(l.x1>l.xMax)
    {
        l.OutCode1=l.OutCode1+10;
    }
    if(l.x1<l.xMin)
    {
        l.OutCode1=l.OutCode1+1;
    }
    //Setting Outcode for (x2,y2)
    if(l.y2>l.yMax)
    {
        l.OutCode2=l.OutCode2+1000;
    }
    if(l.y2<l.yMin)
    {
        l.OutCode2=l.OutCode2+100;
    }
    if(l.x2>l.xMax)
    {
        l.OutCode2=l.OutCode2+10;
    }
    if(l.x2<l.xMin)
    {
        l.OutCode2=l.OutCode2+1;
    }
}

//---------------------------------------------------------------------------------------------------------------------

void MainWindow::draw_Line(QPainter *painter, LineClip l)
 {

     QPen pen(Qt::blue,3,Qt::SolidLine,Qt::RoundCap);
     painter->setPen(pen);

     float x1,y1,x2,y2,xinc,yinc;
     x1=l.x1;
     y1=l.y1;
     x2=l.x2;
     y2=l.y2;
     int dx=x2-x1;
     int dy=y2-y1;

     int steps,i;

     if(abs(dx)>abs(dy))
     {
         steps=abs(dx);
     }
     else
         steps=abs(dy);

     xinc=(dx)/(float)steps;
     yinc=(dy)/(float)steps;
     if((x1<=l.xMax)&&(x1>=l.xMin)&&(y1<=l1.yMax)&&(y1>=l1.yMin))
     {
     painter->drawPoint(round(x1),round(y1));
     }

     for(i=0;i<steps;i++)
     {
         x1+=xinc;
         y1+=yinc;
         if((x1<=l.xMax)&&(x1>=l.xMin)&&(y1<=l1.yMax)&&(y1>=l1.yMin))
         {
         painter->drawPoint(round(x1),round(y1));
         }
     }
}

//---------------------------------------------------------------------------------------------------------------------

void MainWindow::on_pushButton_clicked()
{
    flag=1;
    update();
}
