#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QMouseEvent>
#include<QPainter>
#include<math.h>

#define PI 3.14159265


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    temp[count][0]=event->pos().x();
    temp[count][1]=event->pos().y();
    temp[count][2]=1;
    count++;
}

//----------------------------------------------------------------------------------------------------------------------------------------------

void MainWindow::paintEvent(QPaintEvent *s)
{
    QPainter painter(this);

    ui->horizontalSlider->setRange(0,10);

    if(colorFlag==1)
    {
        QPen pen(Qt::red,penThickness,Qt::SolidLine,Qt::RoundCap);
        painter.setPen(pen);
    }
    else if(colorFlag==2)
    {
        QPen pen(Qt::blue,penThickness,Qt::SolidLine,Qt::RoundCap);
        painter.setPen(pen);
    }
    o1.noOfVert=count;
    if(flag==1)
    {
        for(int i=0;i<count;i++)
            {
                for(int j=0;j<3;j++)
                {
                    o1.xy[i][j]=temp[i][j];
                }
            }
        drawObject(&painter, o1);
    }
    setTransform();
    o3=o1*o2;
    if(flag!=1)
    {

        /*for(int j=0;j<count;j++)
        {
            o1.xy[j][0]=o3.xy[j][0];
            o1.xy[j][1]=o3.xy[j][1];
            o1.xy[j][2]=o3.xy[j][2];
        }*/
    drawObject(&painter, o3);
    }

}

//----------------------------------------------------------------------------------------------------------------------------------------------

void MainWindow::setTransform()
{
    if(flag==2)
    {
        o2.xy[0][0]=1;
        o2.xy[0][1]=0;
        o2.xy[0][2]=0;
        o2.xy[1][0]=0;
        o2.xy[1][1]=1;
        o2.xy[1][2]=0;
        o2.xy[2][0]=ui->TX->text().toInt();
        o2.xy[2][1]=ui->TY->text().toInt();
        o2.xy[2][2]=1;
    }
    if(flag==3)
    {
        o2.xy[0][0]=ui->SX->text().toFloat();
        o2.xy[0][1]=0;
        o2.xy[0][2]=0;
        o2.xy[1][0]=0;
        o2.xy[1][1]=ui->SY->text().toFloat();
        o2.xy[1][2]=0;
        o2.xy[2][0]=0;
        o2.xy[2][1]=0;
        o2.xy[2][2]=1;
    }
    if(flag==4)
    {
        float angle;
        angle=ui->Theta->text().toInt();
        angle=angle*PI/180;

        o2.xy[0][0]=cos(angle);
        o2.xy[0][1]=sin(angle);
        o2.xy[0][2]=0;
        o2.xy[1][0]=-sin(angle);
        o2.xy[1][1]=cos(angle);
        o2.xy[1][2]=0;
        o2.xy[2][0]=0;
        o2.xy[2][1]=0;
        o2.xy[2][2]=1;
    }
    if(flag==5)
    {
        o2.xy[0][0]=1;
        o2.xy[0][1]=ui->shy->text().toInt();
        o2.xy[0][2]=0;
        o2.xy[1][0]=ui->shx->text().toInt();
        o2.xy[1][1]=1;
        o2.xy[1][2]=0;
        o2.xy[2][0]=0;
        o2.xy[2][1]=0;
        o2.xy[2][2]=1;
    }
}

//----------------------------------------------------------------------------------------------------------------------------------------------

void MainWindow::drawObject(QPainter *painter, CObject o)
{
    int l;
    for(l=0;l<count-1;l++)
    {
        painter->drawLine(o.xy[l][0],o.xy[l][1],o.xy[l+1][0],o.xy[l+1][1]);
    }
    painter->drawLine(o.xy[0][0],o.xy[0][1],o.xy[l][0],o.xy[l][1]);

        if(flag==5)
        {
            for(int j=0;j<count;j++)
            {
                temp[j][0]=0;
                temp[j][1]=0;
            }
            count=0;
            flag=0;
        }
}

//----------------------------------------------------------------------------------------------------------------------------------------------

void MainWindow::on_pushButton_clicked()
{
    flag=1;
    update();
}

void MainWindow::on_pushButton_2_clicked()
{
    flag=2;
    update();
}

void MainWindow::on_pushButton_3_clicked()
{
    flag=3;
    update();
}

void MainWindow::on_pushButton_4_clicked()
{
    flag=4;
    update();
}

void MainWindow::on_pushButton_5_clicked()
{
    flag=5;
    update();
}

void MainWindow::on_red_toggled(bool checked)
{
    colorFlag=1;
    update();
}

void MainWindow::on_blue_toggled(bool checked)
{
    colorFlag=2;
    update();
}

void MainWindow::on_horizontalSlider_valueChanged(int value)
{
    penThickness=ui->horizontalSlider->value();
    update();
}
