#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class CObject
{
public:
    float xy[10][3];
    int noOfVert;

    CObject operator *(CObject p)
    {
        CObject temp;

        for(int i=0;i<noOfVert;i++)
        {
            for(int j=0;j<3;j++)
            {
                temp.xy[i][j]=0;
                for(int k=0;k<3;k++)
                {
                 temp.xy[i][j]=temp.xy[i][j]+(xy[i][k]*p.xy[k][j]);
                }
            }
        }
        return temp;
    }
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public slots:
    void paintEvent(QPaintEvent *s);
    void mousePressEvent(QMouseEvent *event);

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    int flag=0;
    int colorFlag=0;
    int penThickness=0;
    int temp[10][3];
    int count=0;
    CObject o1,o2,o3;
    void drawObject(QPainter *painter, CObject o);
    void setTransform();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_red_toggled(bool checked);

    void on_blue_toggled(bool checked);

    void on_horizontalSlider_valueChanged(int value);

private:
    Ui::MainWindow *ui;
};



#endif // MAINWINDOW_H
