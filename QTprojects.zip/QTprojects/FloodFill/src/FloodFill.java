
//package prefinal;

// Program for floodfill

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class FloodFill extends JPanel implements MouseListener {
   
   private BufferedImage image;
   private Graphics2D g2;

   public static void main(String[] args) {
      javax.swing.SwingUtilities.invokeLater(new Runnable() {
         public void run() {
            try {
               createAndShowGUI();
            } catch (Exception e) {
               e.printStackTrace();
            }
         }
      });
   }
   
	public static void createAndShowGUI() {
      JFrame frame = new JFrame("Flooding");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      FloodFill panel = new FloodFill();
      frame.add(panel);
      frame.pack();
      frame.setVisible(true);
	}
	
   public FloodFill() {
      image = new BufferedImage(700, 700, BufferedImage.TYPE_INT_RGB);
      setPreferredSize(new Dimension(image.getWidth(), image.getHeight()));
      setMinimumSize(getPreferredSize());
      g2 = image.createGraphics();
      g2.setColor(Color.white);
      g2.fillRect(0, 0, image.getWidth(), image.getHeight());
      g2.setColor(Color.red);
      
      //final int EYE_RADIUS = 50;
     // final int EYE_GAP = 20;
     // final int CENTER_X = image.getWidth() / 2;
      //final int MOUTH_RADIUS = EYE_RADIUS + 25;
      final int x1=10,y1=20;
      final int x2=60,y2=20;
      final int x3=30,y3=50;
      final int x4=60,y4=70;
      final int x5=10,y5=70;
      g2.drawLine(x1, y1, x2, y2);
      g2.drawLine(x2, y2, x3, y3);
      g2.drawLine(x3, y3, x4, y4);
      g2.drawLine(x4, y4, x5, y5);
      g2.drawLine(x5, y5, x1, y1);
      //g2.drawOval(CENTER_X - EYE_GAP - EYE_RADIUS, 150, EYE_RADIUS, EYE_RADIUS);
      //g2.drawOval(CENTER_X + EYE_GAP, 150, EYE_RADIUS, EYE_RADIUS);
      //g2.drawOval(CENTER_X - MOUTH_RADIUS / 2, 220, MOUTH_RADIUS, MOUTH_RADIUS);
      
      
      addMouseListener(this);
   }
   
   public void paintComponent(Graphics g) {
      g.drawImage(image, 0, 0, null);
   }
   
   public void floodFill(int seedX,
                         int seedY,
                         int rgb) {
      if (seedX < image.getWidth() &&
          /* more */
          image.getRGB(seedX, seedY) == rgb) 
      {
         image.setRGB(seedX, seedY,100);
         update(getGraphics());
         floodFill(seedX - 1, seedY, rgb);
         floodFill(seedX + 1, seedY, rgb);
         floodFill(seedX, seedY - 1, rgb);
         floodFill(seedX, seedY + 1, rgb);
         
      }
   }

   public void mouseClicked(MouseEvent e) {
      System.out.println(e.getX() + ", " + e.getY());
      floodFill(e.getX(), e.getY(), image.getRGB(e.getX(), e.getY()));
      repaint();
   }

   public void mouseEntered(MouseEvent arg0) {   }

   public void mouseExited(MouseEvent arg0) {   }

   public void mousePressed(MouseEvent arg0) {   }

   public void mouseReleased(MouseEvent arg0) {   }
}