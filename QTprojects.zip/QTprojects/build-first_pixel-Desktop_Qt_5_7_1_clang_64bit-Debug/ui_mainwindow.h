/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionDot;
    QAction *actionDash;
    QAction *actionDot_Dash;
    QAction *actionCustom;
    QWidget *centralWidget;
    QLineEdit *x1;
    QLineEdit *y1;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *x2;
    QLineEdit *y2;
    QLabel *label_4;
    QPushButton *DottedLine;
    QPushButton *DashLine;
    QPushButton *DashDotLine;
    QPushButton *CustomLine;
    QMenuBar *menuBar;
    QMenu *menuMenu;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(645, 501);
        actionDot = new QAction(MainWindow);
        actionDot->setObjectName(QStringLiteral("actionDot"));
        actionDash = new QAction(MainWindow);
        actionDash->setObjectName(QStringLiteral("actionDash"));
        actionDot_Dash = new QAction(MainWindow);
        actionDot_Dash->setObjectName(QStringLiteral("actionDot_Dash"));
        actionCustom = new QAction(MainWindow);
        actionCustom->setObjectName(QStringLiteral("actionCustom"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        x1 = new QLineEdit(centralWidget);
        x1->setObjectName(QStringLiteral("x1"));
        x1->setGeometry(QRect(30, 340, 113, 27));
        y1 = new QLineEdit(centralWidget);
        y1->setObjectName(QStringLiteral("y1"));
        y1->setGeometry(QRect(150, 340, 113, 27));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(40, 320, 67, 17));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(170, 320, 67, 17));
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(470, 320, 67, 17));
        x2 = new QLineEdit(centralWidget);
        x2->setObjectName(QStringLiteral("x2"));
        x2->setGeometry(QRect(330, 340, 113, 27));
        y2 = new QLineEdit(centralWidget);
        y2->setObjectName(QStringLiteral("y2"));
        y2->setGeometry(QRect(450, 340, 113, 27));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(340, 320, 67, 17));
        DottedLine = new QPushButton(centralWidget);
        DottedLine->setObjectName(QStringLiteral("DottedLine"));
        DottedLine->setGeometry(QRect(10, 400, 99, 27));
        DashLine = new QPushButton(centralWidget);
        DashLine->setObjectName(QStringLiteral("DashLine"));
        DashLine->setGeometry(QRect(120, 400, 90, 27));
        DashDotLine = new QPushButton(centralWidget);
        DashDotLine->setObjectName(QStringLiteral("DashDotLine"));
        DashDotLine->setGeometry(QRect(220, 400, 121, 31));
        CustomLine = new QPushButton(centralWidget);
        CustomLine->setObjectName(QStringLiteral("CustomLine"));
        CustomLine->setGeometry(QRect(350, 400, 91, 31));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 645, 25));
        menuMenu = new QMenu(menuBar);
        menuMenu->setObjectName(QStringLiteral("menuMenu"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuMenu->menuAction());
        menuMenu->addAction(actionDot);
        menuMenu->addAction(actionDash);
        menuMenu->addAction(actionDot_Dash);
        menuMenu->addAction(actionCustom);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        actionDot->setText(QApplication::translate("MainWindow", "Dot", Q_NULLPTR));
        actionDash->setText(QApplication::translate("MainWindow", "Dash", Q_NULLPTR));
        actionDot_Dash->setText(QApplication::translate("MainWindow", "Dot Dash", Q_NULLPTR));
        actionCustom->setText(QApplication::translate("MainWindow", "Custom", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "X1", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "Y1", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "Y2", Q_NULLPTR));
        x2->setText(QString());
        y2->setText(QString());
        label_4->setText(QApplication::translate("MainWindow", "X2", Q_NULLPTR));
        DottedLine->setText(QApplication::translate("MainWindow", "Dotted Line", Q_NULLPTR));
        DashLine->setText(QApplication::translate("MainWindow", "Dash Line", Q_NULLPTR));
        DashDotLine->setText(QApplication::translate("MainWindow", "Dash Dot Line", Q_NULLPTR));
        CustomLine->setText(QApplication::translate("MainWindow", "Custom Line", Q_NULLPTR));
        menuMenu->setTitle(QApplication::translate("MainWindow", "Menu", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
