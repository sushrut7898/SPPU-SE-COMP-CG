#ifndef STATIONARY_H
#define STATIONARY_H
#include<QPainter>

class stationary        //contains methods to draw stationary images
{
public:
    stationary();


    void drawPole(QPainter *, int w, int h);       //flag pole

    void drawSteps(QPainter *, int w, int h);       //flag steps
};

#endif // STATIONARY_H
