#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<stationary.h>
#include<QThread>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    w=this->width();
    h=this->height();

    time=0;
    x=0;        //initialilly
    y=0;
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);

    stationary s; //object of stationary class

    s.drawPole(&painter,w,h);       //draw stationary parts
    s.drawSteps(&painter,w,h);



    if(time<3)      //for first 3 seconds, the unfolded flag translates upwards.
    {
        if(y<200)   //for complete flag height
        painter.fillRect(w/2-2,h-y-250,15,20,Qt::red);      //filled rectangle(topLeft X, topLeft Y, width,height)
        painter.fillRect(w/2-2,h-y-230,15,20,Qt::white);
        painter.fillRect(w/2-2,h-y-210,15,20,Qt::darkGreen);

        QThread::msleep(15);    //time delay in milliseconds

        time=time+0.015;    //increase the time elapsed
        y++;              //increment vertical translation

        update();       //call painEvent() again
    }


    if(time>=3)    //after 3 seconds, the flag starts unfolding horizontally
    {
        if(x==0)
        QThread::msleep(100);

        if(x<150)       //the length of the flag is set to be 150px
        {
            painter.fillRect(w/2,h-449,x+1,30,Qt::red);     //fill the rectangle as per the horizontal translation variable X.
            painter.fillRect(w/2,h-419,x+1,30,Qt::white);
            painter.fillRect(w/2,h-389,x+1,30,Qt::darkGreen);

            QPen blue(Qt::blue,2);        //for Ashokachakra (outline)
            painter.setPen(blue);
            painter.drawEllipse(w/2+x*0.4,h-419,x*0.2,30);  //transform ashokachakra from an ellispe to a circle, using fractional incrementation.
            x++;                    //increment horizontal translation variable, X

            QThread::msleep(10);    //delay for 10 milliseconds.

            update();           //call paintEvent() again.
        }



        if(x==150)      //if horizontal translation is complete, permanently display the complete flag.
       {
            painter.fillRect(w/2,h-449,150,30,Qt::red);     //filled rectangles with final values.
            painter.fillRect(w/2,h-419,150,30,Qt::white);
            painter.fillRect(w/2,h-389,150,30,Qt::darkGreen);

            QPen blue(Qt::blue,2);
            painter.setPen(blue);
            painter.drawEllipse(w/2+150*0.4,h-419,x*0.2,30);
       }
    }

}
