/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *x1;
    QLabel *y1;
    QLabel *x2;
    QLabel *y2;
    QLineEdit *x1Input;
    QLineEdit *y1Input;
    QLineEdit *x2Input;
    QLineEdit *y2Input;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(659, 400);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        x1 = new QLabel(centralWidget);
        x1->setObjectName(QStringLiteral("x1"));
        x1->setGeometry(QRect(70, 270, 60, 16));
        y1 = new QLabel(centralWidget);
        y1->setObjectName(QStringLiteral("y1"));
        y1->setGeometry(QRect(70, 300, 60, 16));
        x2 = new QLabel(centralWidget);
        x2->setObjectName(QStringLiteral("x2"));
        x2->setGeometry(QRect(260, 260, 60, 16));
        y2 = new QLabel(centralWidget);
        y2->setObjectName(QStringLiteral("y2"));
        y2->setGeometry(QRect(260, 290, 60, 16));
        x1Input = new QLineEdit(centralWidget);
        x1Input->setObjectName(QStringLiteral("x1Input"));
        x1Input->setGeometry(QRect(90, 270, 113, 21));
        y1Input = new QLineEdit(centralWidget);
        y1Input->setObjectName(QStringLiteral("y1Input"));
        y1Input->setGeometry(QRect(90, 300, 113, 21));
        x2Input = new QLineEdit(centralWidget);
        x2Input->setObjectName(QStringLiteral("x2Input"));
        x2Input->setGeometry(QRect(280, 260, 113, 21));
        y2Input = new QLineEdit(centralWidget);
        y2Input->setObjectName(QStringLiteral("y2Input"));
        y2Input->setGeometry(QRect(280, 290, 113, 21));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(260, 230, 113, 32));
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(90, 230, 113, 32));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 659, 19));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        x1->setText(QApplication::translate("MainWindow", "x1", 0));
        y1->setText(QApplication::translate("MainWindow", "y1", 0));
        x2->setText(QApplication::translate("MainWindow", "x2", 0));
        y2->setText(QApplication::translate("MainWindow", "y2", 0));
        pushButton->setText(QApplication::translate("MainWindow", "DDA", 0));
        pushButton_2->setText(QApplication::translate("MainWindow", "Bresenham", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
