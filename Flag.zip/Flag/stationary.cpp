#include "stationary.h"
#include<QPainter>
#include<mainwindow.h>
stationary::stationary()
{

}

void stationary::drawPole(QPainter *painter,int w,int h)
{
    painter->drawLine(w/2-1,h-150,w/2-1,h-450);              //height of the flag pole
    painter->drawLine(w/2+2,h-150,w/2+2,h-450);
    painter->drawEllipse(w/2-3,h-456,7,7);                   //pully of the flag pole
}

void stationary::drawSteps(QPainter *painter,int w,int h)
{
    painter->drawRect(w/2-30,h-150,60,20);                   //for drawing three stationary steps
    painter->drawRect(w/2-60,h-130,120,20);
    painter->drawRect(w/2-90,h-110,180,20);

}

