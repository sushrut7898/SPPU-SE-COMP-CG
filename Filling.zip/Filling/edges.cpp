#include "edges.h"

Edges::Edges(QVector<Matcol> vertices)
{   counter = 0;
    int n = vertices.size();
    if(n < 3){
        return;
    }
    xmin =vertices[0].x;
    xmax =vertices[0].x;
    ymin =vertices[0].y;
    ymax =vertices[0].y;
    for(int i=1;i<n;i++){
        if(vertices[i].x < xmin){
            xmin =vertices[i].x;
        }
        if(vertices[i].y < ymin){
            ymin =vertices[i].y;
        }
        if(vertices[i].x>xmax){
            xmax =vertices[i].x;
        }
        if(vertices[i].y>ymax){
            ymax =vertices[i].y;
        }
    }
    for(int i=0;i<n-1;i++){
        float x1= vertices[i].x;
        float y1= vertices[i].y;
        float x2= vertices[i+1].x;
        float y2= vertices[i+1].y;
        Edge e(x1,y1,x2,y2);
        if(y1>y2){
            e.ymax =y1;
            e.ymin = y2;
        }
        else{
            e.ymax =y2;
            e.ymin = y1;
        }
        sides.push_back(e);
    }
    float x1= vertices[n-1].x;
    float y1= vertices[n-1].y;
    float x2= vertices[0].x;
    float y2= vertices[0].y;
    Edge e(x1,y1,x2,y2);
    if(y1>y2){
        e.ymax =y1;
        e.ymin = y2;
    }
    else{
        e.ymax =y2;
        e.ymin =y1;
    }
    sides.push_back(e);
}

int Edges::sidessize(){
    return sides.size();
}


QVector<Edge> Edges:: getSides(){
    return sides;
}


QVector<Line> Edges:: calcLines(){
    QVector<Line> ans;
    for(int ya = ymin-1; ya<ymax+2;ya++){
        QVector<Point> intersections;
        intersections.clear();
        for(int nc = 0 ; nc< sides.size(); nc++){

            if(float(ya)<= sides[nc].ymax && float(ya) > sides[nc].ymin){
                //counter++;
                float xa = (float(ya)-sides[nc].c)/(sides[nc].m);
                Point p;
                p.x=xa;
                p.y=ya;
                intersections.push_back(p);
            }
        }

        //Sort with x

        for(int i =0; i<intersections.size();i++){
            for(int j =0;  j<intersections.size();j++){
                if(intersections[i].x >intersections[j].x){
                    Point t = intersections[i];
                    intersections[i] = intersections[j];
                    intersections[j] = t;
                }
            }
        }



        if(intersections.size()>=2){
           for(int g =0 ; g <intersections.size()/2;g++){
               Line l(intersections[2*g].x,intersections[2*g].y ,intersections[2*g +1].x,intersections[2*g +1].y );
               ans.push_back(l);

           }



        }
    }
    return ans;
}

