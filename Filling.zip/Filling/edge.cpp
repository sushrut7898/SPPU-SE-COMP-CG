#include "edge.h"

Edge::Edge()
{
    m=c=1;
}
Edge::Edge(float x1,float y1,float x2,float y2)
{
    // y=mx+c
    m = (y2-y1)/(x2-x1);
    c= y1- (m*x1);
}
