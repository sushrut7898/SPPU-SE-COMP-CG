#include "point.h"

Point::Point()
{

}

float Point::distance(float x1, float y1,float x2, float y2){
    float ans = 0;
    ans = (x1-x2)*(x1-x2)  + (y1-y2)*(y1-y2);
    ans = qSqrt(ans);
    return ans;
}
