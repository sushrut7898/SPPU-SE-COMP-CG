#include "matcol.h"

Matcol::Matcol()
{
    z=1;
}
QVector<Matcol> Matcol::translateorigin(QVector <Matcol> m, int n, int h){
    QVector <Matcol> ans;

    for (int i =0; i<n; i++){
        Matcol p;

        p.x= m[i].x;
        p.y= h-m[i].y;
        ans.push_back(p);
    }
    return ans;
}
QVector <Matcol> Matcol::translate(QVector <Matcol> m, int n,int xshift, int yshift){
    QVector <Matcol> ans;

    for (int i =0; i<n; i++){
        Matcol p;
        p.x= m[i].x +xshift;
        p.y= m[i].y +yshift;
        ans.push_back(p);
    }
    return ans;
}
QVector <Matcol> Matcol::rotate(QVector <Matcol> m, int n,int thet){
    QVector <Matcol> ans;
    float theta = qDegreesToRadians((float)thet);
    for (int i =0; i<n; i++){
        Matcol p;

        p.x= m[i].x* qCos(theta) + m[i].y* qSin(theta) ;
        p.y= m[i].y* qCos(theta) -m[i].x* qSin(theta) ;
        ans.push_back(p);
    }

    return ans;
}
QVector <Matcol> Matcol::scale(QVector <Matcol> m, int n,float sx,float sy){
    QVector <Matcol> ans;
    for (int i =0; i<n; i++){
        Matcol p;

        p.x= m[i].x*sx;
        p.y= m[i].y*sy;
        ans.push_back(p);
    }

    return ans;
}
QVector <Matcol> Matcol::shear(QVector <Matcol> m, int n,float sx,float sy){
    QVector <Matcol> ans;
    for (int i =0; i<n; i++){
        Matcol p;

        p.x= m[i].x + m[i].y*sx;
        p.y= m[i].y + m[i].x*sy;
        ans.push_back(p);
    }

    return ans;
}
QVector<Matcol> Matcol::reflectabtX(QVector <Matcol> m,int n){
    QVector <Matcol> ans;

    for (int i =0; i<n; i++){
        Matcol p;

        p.x= m[i].x;
        p.y= -m[i].y;
        ans.push_back(p);
    }
    return ans;
}
QVector<Matcol> Matcol::reflectabtY(QVector <Matcol> m,int n){
    QVector <Matcol> ans;

    for (int i =0; i<n; i++){
        Matcol p;

        p.x= -m[i].x;
        p.y= m[i].y;
        ans.push_back(p);
    }
    return ans;
}
QVector<Matcol> Matcol::reflectabtO(QVector <Matcol> m,int n){
    QVector <Matcol> ans;

    for (int i =0; i<n; i++){
        Matcol p;

        p.x= -m[i].x;
        p.y= -m[i].y;
        ans.push_back(p);
    }
    return ans;
}
