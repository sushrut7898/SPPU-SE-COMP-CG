#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QVector>
#include <QInputDialog>
#include "matcol.h"
#include "QPainter"
#include "edges.h"
#include "line.h"
#include "edge.h"
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
signals:
    void mousePressed( const QPoint& );

public:
    QVector <Matcol> vertices;
    int n;
    int flag;
    int ex;
    int type;
    int fill;
    int xmax,ymax;
    int linetype;
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void inputObject();
    void displayObject(QPainter *q, QVector <Matcol> vertices);
    void paintEvent(QPaintEvent *event);
    void mousePressEvent( QMouseEvent* ev );
    void scanline(QPainter *q, QVector <Matcol> vertices);
    void QTlines(QPainter *q, QVector <Matcol> vertices);
    void drawAxis(QPainter *q);
    void dda(QPainter *q, float x1,float y1, float x2, float y2);
    void DDAlines(QPainter *q, QVector <Matcol> vertices);
    void bre(QPainter *q, float x1,float y1, float x2, float y2);
    void BRElines(QPainter *q, QVector <Matcol> vertices);
    void quadPattern(QPainter *q, QVector <Matcol> vertices);
    void BREcircle(QPainter *q, float xc,float yc,float r, int clr);
    void reftcircle(QPainter *q, float xc,float yc,float x1, float x2);
    void triPattern(QPainter *q, QVector <Matcol> vertices);

private slots:
    void on_translatebtn_clicked();

    void on_originalbtn_clicked();

    void on_rotatebtn_clicked();

    void on_scalebtn_clicked();

    void on_shearbtn_clicked();

    void on_reftxbtn_clicked();

    void on_reftybtn_clicked();

    void on_reftobtn_clicked();

    void on_clrbtn_clicked();

    void on_gonbtn_clicked();

    void on_hedronbtn_clicked();

    void on_scnlinebtn_clicked();

    void on_makeorigbtn_clicked();

    void on_manualinp_clicked();

    void on_ddabtn_clicked();

    void on_qtlinebtn_clicked();

    void on_scnlinebtn_3_clicked();

    void on_bresenlinebtn_clicked();

    void on_brecircle_clicked();

    void on_tripatbtn_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
