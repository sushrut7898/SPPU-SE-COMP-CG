#include "mainwindow.h"
#include "ui_mainwindow.h"

QVector <Matcol> vertices;
QVector <Matcol> vertices_orig;
int n;


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    type=0;
    flag=0;
    ex=1;
    n=0;
    linetype=0;
    ui->xcor->appendPlainText("0");
    ui->ycor->appendPlainText("0");
    ui->scaleX->appendPlainText("1");
    ui->scaleY->appendPlainText("1");
    ui->shearX->appendPlainText("0");
    ui->shearY->appendPlainText("0");
    ui->thetaval->appendPlainText("0");
    ui->redclr->appendPlainText("0");
    ui->greenclr->appendPlainText("0");
    ui->blueclr->appendPlainText("0");
    //inputObject();

}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::inputObject()
{

    n= QInputDialog::getInt(this, "Object", "Enter no of vertices");
    for(int i =0; i<n; i++){
        Matcol m;
        m.x= QInputDialog::getInt(this, "Object", "Enter x cordinate of vertex ");
        m.y= QInputDialog::getInt(this, "Object", "Enter y cordinate of vertex ");
        vertices_orig.push_back(m);


    }


}

void MainWindow::displayObject(QPainter *q, QVector <Matcol> vertices)
{
        if(linetype ==0)
            QTlines(q,vertices);
        if(linetype ==1)
            DDAlines(q,vertices);
        if(linetype==2)
            BRElines(q,vertices);
        if(fill==1){
            scanline(q , vertices );
        }
}
void MainWindow::drawAxis(QPainter *q){
    QPen pen(Qt::black,2,Qt::SolidLine);
    q->setPen(pen);
    q->drawLine(xmax/2,0,xmax/2,ymax);
    q->drawLine(0,ymax/2,xmax,ymax/2);
    QPen pen1(Qt::black,5,Qt::SolidLine);
    q->setPen(pen1);
    q->drawPoint(xmax/2,ymax/2);

}
void MainWindow::QTlines(QPainter *q, QVector <Matcol> vertices){
    if(n<2){
        return;
    }
    n=vertices.size();
    QPen pen(Qt::black,1,Qt::SolidLine);
    q->setPen(pen);
    if(type==0){
        for (int i=0;i <n-1;i++){
            q->drawLine(vertices[i].x+xmax/2,ymax/2-vertices[i].y,vertices[i+1].x+xmax/2,ymax/2-vertices[i+1].y);
        }
        q->drawLine(vertices[n-1].x +xmax/2,ymax/2-vertices[n-1].y,vertices[0].x+xmax/2,ymax/2-vertices[0].y);
    }

    if(type==1){
        for (int i=0;i <n;i++){
            for (int j=0;j <n;j++){
                 q->drawLine(vertices[i].x+xmax/2,ymax/2-vertices[i].y,vertices[j].x+xmax/2,ymax/2-vertices[j].y);
            }
        }
    }

}
void MainWindow::DDAlines(QPainter *q, QVector <Matcol> vertices){
    if(n<2){
        return;
    }
    n=vertices.size();
    QPen pen(Qt::blue,1,Qt::SolidLine);
    q->setPen(pen);
    if(type==0){
        for (int i=0;i <n-1;i++){
            dda(q,vertices[i].x+xmax/2,ymax/2-vertices[i].y,vertices[i+1].x+xmax/2,ymax/2-vertices[i+1].y);
        }
        dda(q,vertices[n-1].x +xmax/2,ymax/2-vertices[n-1].y,vertices[0].x+xmax/2,ymax/2-vertices[0].y);
    }

    if(type==1){
        for (int i=0;i <n;i++){
            for (int j=0;j <n;j++){
                 dda(q,vertices[i].x+xmax/2,ymax/2-vertices[i].y,vertices[j].x+xmax/2,ymax/2-vertices[j].y);
            }
        }
    }

}

void MainWindow::BRElines(QPainter *q, QVector <Matcol> vertices){
    if(n<2){
        return;
    }
    n=vertices.size();
    QPen pen(Qt::green,1,Qt::SolidLine);
    q->setPen(pen);
    if(type==0){
        for (int i=0;i <n-1;i++){
            bre(q,vertices[i].x+xmax/2,ymax/2-vertices[i].y,vertices[i+1].x+xmax/2,ymax/2-vertices[i+1].y);
        }
        bre(q,vertices[n-1].x +xmax/2,ymax/2-vertices[n-1].y,vertices[0].x+xmax/2,ymax/2-vertices[0].y);
    }

    if(type==1){
        for (int i=0;i <n;i++){
            for (int j=0;j <n;j++){
                 bre(q,vertices[i].x+xmax/2,ymax/2-vertices[i].y,vertices[j].x+xmax/2,ymax/2-vertices[j].y);
            }
        }
    }

}
void MainWindow::dda(QPainter *q, float x1,float y1, float x2, float y2){
    float dx,dy,len;
    dx = x2-x1;
    dy = y2-y1;
    if(abs(dx) >abs(dy)){
        len = dx;
    }
    else{
        len=dy;
    }
    len = abs(len);
    float x=x1;
    float y=y1;
    q->drawPoint(x,y);
    for(float i=1;i<=len;i++){
       x=x+(dx/len);
       y=y+(dy/len);
       q->drawPoint(x,y);
    }

}
void MainWindow::bre(QPainter *q, float x1,float y1,float x2,float y2)
{
    float i,x,y,dx,dy,G,temp;
    int exflag=0;
    dx=abs(x2-x1);
    dy=abs(y2-y1);
    float sx = (x2-x1)/(dx);
    float sy = (y2-y1)/(dy);
    x=x1;
    y=y1;
    if(dy>dx){
        temp = dx;
        dx=dy;
        dy=temp;
        exflag=1;
    }

    G= 2*dy-dx;
    for(i=0;i<dx;i++){
        q->drawPoint(x,y);

            while(G >= 0){
              if(exflag==1)
                  x = x + sx;
              else
                y = y + sy;

              G = G - 2* dx;

            }
            if(exflag==1)
                y = y + sy;
            else
                x = x + sx;
            G = G + 2 * dy;
    }
}

void MainWindow::BREcircle(QPainter *q, float xc,float yc,float r, int clr){

    if(clr==0){
        QPen pen(Qt::black,1,Qt::SolidLine);
        q->setPen(pen);
    }
    if(clr==1){
        QPen pen(Qt::red,1,Qt::SolidLine);
        q->setPen(pen);
    }
    if(clr==2){
        QPen pen(Qt::blue,1,Qt::SolidLine);
        q->setPen(pen);
    }

    float x = 0, y = r;
        float d = 3 - 2 * r;
        while (y >= x)
        {
            // for each pixel we will
            // draw all eight pixels
            reftcircle(q,xc, yc, x, y);
            x++;

            // check for decision parameter
            // and correspondingly
            // update d, x, y
            if (d > 0)
            {
                y--;
                d = d + 4 * (x - y) + 10;
            }
            else
                d = d + 4 * x + 6;
            reftcircle(q,xc, yc, x, y);
        }
}
void MainWindow::reftcircle(QPainter *q, float xc,float yc,float x1, float y1){

    q->drawPoint(xc+x1+xmax/2,ymax/2-(yc+y1));
    q->drawPoint(xc-x1+xmax/2,ymax/2-(yc+y1));
    q->drawPoint(xc+x1+xmax/2,ymax/2-(yc-y1));
    q->drawPoint(xc-x1+xmax/2,ymax/2-(yc-y1));
    q->drawPoint(xc+y1+xmax/2,ymax/2-(yc+x1));
    q->drawPoint(xc-y1+xmax/2,ymax/2-(yc+x1));
    q->drawPoint(xc+y1+xmax/2,ymax/2-(yc-x1));
    q->drawPoint(xc-y1+xmax/2,ymax/2-(yc-x1));

}

void MainWindow::quadPattern(QPainter *q, QVector <Matcol> vertices){
     n= vertices.size();
     if(n!=4){
         ui->console->clear();
         ui->console->appendPlainText("Draw a Quadrilateral only.");
         return;
     }
     displayObject(q,vertices);
     Point pt[4];
     pt[0].x = (vertices[0].x + vertices[1].x)/2;
     pt[1].x = (vertices[1].x + vertices[2].x)/2;
     pt[2].x = (vertices[2].x + vertices[3].x)/2;
     pt[3].x = (vertices[3].x + vertices[0].x)/2;
     pt[0].y = (vertices[0].y + vertices[1].y)/2;
     pt[1].y = (vertices[1].y + vertices[2].y)/2;
     pt[2].y = (vertices[2].y + vertices[3].y)/2;
     pt[3].y = (vertices[3].y + vertices[0].y)/2;

     QPen pen(Qt::red,1,Qt::SolidLine);
     q->setPen(pen);

     for(int i=0;i<3;i++){
         q->drawLine(pt[i].x+xmax/2,ymax/2-pt[i].y,pt[i+1].x+xmax/2,ymax/2-pt[i+1].y);
     }
     q->drawLine(pt[3].x+xmax/2,ymax/2-pt[3].y,pt[0].x+xmax/2,ymax/2-pt[0].y);

     Point pr[4];
     pr[0].x = (pt[0].x + pt[1].x)/2;
     pr[1].x = (pt[1].x + pt[2].x)/2;
     pr[2].x = (pt[2].x + pt[3].x)/2;
     pr[3].x = (pt[3].x + pt[0].x)/2;
     pr[0].y = (pt[0].y + pt[1].y)/2;
     pr[1].y = (pt[1].y + pt[2].y)/2;
     pr[2].y = (pt[2].y + pt[3].y)/2;
     pr[3].y = (pt[3].y + pt[0].y)/2;

     QPen pen1(Qt::blue,1,Qt::SolidLine);
     q->setPen(pen1);

     for(int i=0;i<3;i++){
         q->drawLine(pr[i].x+xmax/2,ymax/2-pr[i].y,pr[i+1].x+xmax/2,ymax/2-pr[i+1].y);
     }
     q->drawLine(pr[3].x+xmax/2,ymax/2-pr[3].y,pr[0].x+xmax/2,ymax/2-pr[0].y);
}
void MainWindow::triPattern(QPainter *q, QVector <Matcol> vertices){
     n= vertices.size();
     if(n!=3){
         ui->console->clear();
         ui->console->appendPlainText("Draw a Triangle only.");
         return;
     }
     displayObject(q,vertices);

     //Incircle
     float a,b,c,s,ri,cix,ciy;
     Point p;
     a = p.distance(vertices[1].x,vertices[1].y,vertices[2].x,vertices[2].y);
     b = p.distance(vertices[0].x,vertices[0].y,vertices[2].x,vertices[2].y);
     c = p.distance(vertices[1].x,vertices[1].y,vertices[0].x,vertices[0].y);
     s = (a+b+c)/2;
     cix = (a *vertices[0].x  + b*vertices[1].x + c*vertices[2].x)/(a+b+c);
     ciy = (a *vertices[0].y  + b*vertices[1].y + c*vertices[2].y)/(a+b+c);
     ri =((s-a)*(s-b)*(s-c))/s;
     ri = qSqrt(ri);
     BREcircle(q,cix,ciy,ri,1);

     //Circumcenter
     float ccx,ccy,rc,ax,ay,bx,by,m1,m2,c1,c2;

     m1 = (vertices[0].y -vertices[1].y)/(vertices[0].x -vertices[1].x);
     m1 = -1/m1;
     m2 = (vertices[1].y -vertices[2].y)/(vertices[1].x -vertices[2].x);
     m2 = -1/m2;

     ax = (vertices[0].x + vertices[1].x)/2;
     ay= (vertices[0].y + vertices[1].y)/2;
     bx = (vertices[1].x + vertices[2].x)/2;
     by= (vertices[1].y + vertices[2].y)/2;

     c1 = ay - m1*ax;
     c2 = by - m2*bx;

     ccx = (c2-c1)/(m1-m2);
     ccy = m1*ccx +c1;

     rc = p.distance(ccx,ccy,vertices[0].x,vertices[0].y);
     BREcircle(q,ccx,ccy,rc,2);


}

void MainWindow::scanline(QPainter *q,QVector <Matcol> vertices){
    Edges ed(vertices);
    QVector <Line> lines = ed.calcLines();
    int r =ui->redclr->toPlainText().toInt();
    int g = ui->greenclr->toPlainText().toInt();
    int b = ui->blueclr->toPlainText().toInt();
    QColor c(r,g,b);
    QPen pen(Qt::red,1,Qt::SolidLine);
    q->setPen(pen);
    q->setPen(c);
    for(int i =0; i<lines.size();i++ ){
        q->drawLine(lines[i].x1 + (xmax/2), (ymax/2) - lines[i].y1 ,lines[i].x2 + (xmax/2) , (ymax/2) -lines[i].y2 );
    }
    fill=0;

}
void MainWindow::paintEvent(QPaintEvent *event){
    Q_UNUSED(event);

    xmax= QWidget::width();
    ymax =QWidget::height();

    QPainter painter(this);
    drawAxis(&painter);
    if(ex==0){
        return;
    }

    Matcol m;
    if(flag==0){
    vertices=vertices_orig;
    displayObject(&painter,vertices_orig);
    ex=0;
    }

    if (flag==1){
        int xs = ui->xcor->toPlainText().toInt();
        int ys = ui->ycor->toPlainText().toInt();
        vertices = m.translate(vertices,n,xs,ys);
        displayObject(&painter,vertices);
        ex=0;
    }
    if (flag==2){
        int thet = ui->thetaval->toPlainText().toInt();
        vertices = m.rotate(vertices,n,thet);
        displayObject(&painter,vertices);
        ex=0;
    }
    if(flag==3){
        float sx = ui->scaleX->toPlainText().toFloat();
        float sy = ui->scaleY->toPlainText().toFloat();
        vertices = m.scale(vertices,n,sx,sy);
        displayObject(&painter,vertices);
        ex=0;
    }
    if(flag==4){
        float sx = ui->shearX->toPlainText().toFloat();
        float sy = ui->shearY->toPlainText().toFloat();
        vertices = m.shear(vertices,n,sx,sy);
        displayObject(&painter,vertices);
        ex=0;
    }
    if(flag==5){
        vertices= m.reflectabtX(vertices,n);
        displayObject(&painter,vertices);
        ex=0;
    }
    if(flag==6){
        vertices= m.reflectabtY(vertices,n);
        displayObject(&painter,vertices);
        ex=0;
    }
    if(flag==7){
        vertices= m.reflectabtO(vertices,n);
        displayObject(&painter,vertices);
        ex=0;
    }
    if(flag==9){
        displayObject(&painter,vertices);
        ex=0;
    }
    if(flag==10){
        quadPattern(&painter,vertices);
        ex=0;
    }
    if(flag==11){
        triPattern(&painter,vertices);
        ex=0;
    }
    if(flag==15){
        float xc = ui->xcenter->toPlainText().toFloat();
        float yc = ui->ycenter->toPlainText().toFloat();
        float rc = ui->cradius->toPlainText().toFloat();
        BREcircle(&painter,xc,yc,rc,0);
        ex=0;
    }
}

void MainWindow::on_translatebtn_clicked()
{
    flag=1;
    ex=1;
    QWidget::update();
}

void MainWindow::on_originalbtn_clicked()
{
    flag=0;
    ex=1;
    QWidget::update();
}

void MainWindow::on_rotatebtn_clicked()
{
    flag=2;
    ex=1;
    QWidget::update();
}

void MainWindow::on_scalebtn_clicked()
{
    flag=3;
    ex=1;
    QWidget::update();
}

void MainWindow::on_shearbtn_clicked()
{
    flag=4;
    ex=1;
    QWidget::update();
}

void MainWindow::mousePressEvent( QMouseEvent* ev )
{
    const QPoint p = ev->pos();
    int xmax= QWidget::width();
    int ymax =QWidget::height();
    Matcol r;
    r.x=p.x()-xmax/2;
    r.y=ymax/2 -p.y();
    vertices_orig.push_back(r);
    n++;
    flag=0;
    ex=1;
    QWidget::update();
    emit mousePressed( p );
}

void MainWindow::on_reftxbtn_clicked()
{
    flag=5;
    ex=1;
    QWidget::update();
}

void MainWindow::on_reftybtn_clicked()
{
    flag=6;
    ex=1;
    QWidget::update();
}

void MainWindow::on_reftobtn_clicked()
{
    flag=7;
    ex=1;
    QWidget::update();
}

void MainWindow::on_clrbtn_clicked()
{
    for(int i=0;i<n;i++){
        vertices.pop_back();
        vertices_orig.pop_back();
    }
    n=0;
    ex=1;
    flag=0;
    QWidget::update();
}

void MainWindow::on_gonbtn_clicked()
{
    type=0;
    ex=1;
    flag=9;
    QWidget::update();
}

void MainWindow::on_hedronbtn_clicked()
{
    type=1;
    ex=1;
    flag=9;
    QWidget::update();
}

void MainWindow::on_scnlinebtn_clicked()
{
    type=0;
    flag=9;
    ex=1;
    fill=1;
    QWidget::update();
}

void MainWindow::on_makeorigbtn_clicked()
{
    vertices_orig = vertices;
}

void MainWindow::on_manualinp_clicked()
{
    vertices.clear();
    vertices_orig.clear();
    inputObject();
    flag=0;
    ex=1;
    QWidget::update();
}

void MainWindow::on_ddabtn_clicked()
{
    linetype=1;
    flag=9;
    ex=1;
    QWidget::update();
}

void MainWindow::on_qtlinebtn_clicked()
{
    linetype=0;
    flag=9;
    ex=1;
    QWidget::update();
}

void MainWindow::on_scnlinebtn_3_clicked()
{
    flag=10;
    ex=1;
    QWidget::update();
}

void MainWindow::on_bresenlinebtn_clicked()
{
    linetype=2;
    flag=9;
    ex=1;
    QWidget::update();
}

void MainWindow::on_brecircle_clicked()
{
    vertices.clear();
    vertices_orig.clear();
    flag=15;
    ex=1;
    QWidget::update();
}

void MainWindow::on_tripatbtn_clicked()
{
    flag=11;
    ex=1;
    QWidget::update();
}
