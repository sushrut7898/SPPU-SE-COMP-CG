#ifndef EDGES_H
#define EDGES_H


#include <QVector>
#include "edge.h"
#include "point.h"
#include "matcol.h"
#include "line.h"
#include <iostream>
#include "mainwindow.h"

using namespace std;
class Edges
{
public:
    //Edges();
    Edges(QVector<Matcol> vertices);
    QVector<Edge> sides;
    float xmin,xmax,ymin,ymax;
    int counter;
    QVector<Line> calcLines();
    int sidessize();
    QVector<Edge> getSides();
};

#endif // EDGES_H
