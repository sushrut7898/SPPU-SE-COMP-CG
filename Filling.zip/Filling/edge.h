#ifndef EDGE_H
#define EDGE_H

class Edge
{
public:
    Edge();
    Edge(float x1,float y1,float x2,float y2);
    float m,c;
    float ymax, ymin;
};

#endif // EDGE_H
