#ifndef MATCOL_H
#define MATCOL_H


#include <QVector>
#include "QWidget"
#include "QtMath"
class Matcol
{
public:
     float x,y,z;
    Matcol();
    QVector <Matcol> translateorigin(QVector <Matcol> m, int n,int h);
    QVector <Matcol> translate(QVector <Matcol> m, int n,int xshift, int yshift);
    QVector <Matcol> rotate(QVector <Matcol> m, int n,int theta);
    QVector <Matcol> scale(QVector <Matcol> m, int n,float sx,float sy);
    QVector <Matcol> shear(QVector <Matcol> m, int n,float sx,float sy);
    QVector<Matcol> reflectabtY(QVector <Matcol> m,int n);
    QVector<Matcol> reflectabtX(QVector <Matcol> m,int n);
    QVector<Matcol> reflectabtO(QVector <Matcol> m,int n);
};

#endif // MATCOL_H
