#include "line.h"

Line::Line()
{
    x1=x2=y1=y2=0;
}
Line::Line(float a, float b, float c, float d)
{
    x1=a;
    y1=b;
    x2=c;
    y2=d;
}

