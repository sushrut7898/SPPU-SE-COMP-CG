#ifndef POINT_H
#define POINT_H
#include <QtMath>

class Point
{
public:
    Point();
    float x,y;
    float distance(float x1, float y1,float x2, float y2);
};

#endif // POINT_H
