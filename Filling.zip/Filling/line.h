#ifndef LINE_H
#define LINE_H


class Line
{
public:
    Line();
    Line(float a, float b, float c, float d);
    float x1,x2,y1,y2;
};

#endif // LINE_H
